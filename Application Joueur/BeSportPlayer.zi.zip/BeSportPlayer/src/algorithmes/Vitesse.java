package algorithmes;

import java.util.Date;

public class Vitesse {

   private double vitesse;
   private Date lastTime;
   private Point lastPoint;
   
   //fonction constructeur
   public Vitesse (){
       this.vitesse = 0.0;
   }
   
   public void updateVitesse (Point p){
	   
	   if(this.lastTime == null || this.lastPoint==null){
	       this.lastTime = new Date();
	       this.lastPoint = p;
	   }
	   else{
	       //On prend le point pr�c�dent qu'on garde dans p1 pour le calcul et on met le nouveau point dans l'attribut pour le calcul de vitesse suivant
	       Point p1 = new Point(this.lastPoint.getX(), this.lastPoint.getY(),this.lastPoint.getZ());
	       this.lastPoint = p;
	       
	       //Calcul du temps en milliseconde entre le point d'avant et le nouveau point
	       long t0 = this.lastTime.getTime();
	       this.lastTime = new Date();
	       long t1 = this.lastTime.getTime();
	       long tdiff = t1 - t0;
	       
	       //Calcul de la vitesse
	       this.vitesse = (1000/tdiff) * Math.sqrt(Math.pow(this.lastPoint.getX() - p1.getX(),2.0)+ Math.pow(this.lastPoint.getY()-p1.getY(),2.0));
  
	   }
}
   
   public void setLastTime (Date d){
       this.lastTime = d;
   }
   
   public void setLastPoint (Point p){
       this.lastPoint = p;
   }
   
   public double getVitesse()
   {
       return this.vitesse;
   }
   
   public Date getLastTime()
   {
       return this.lastTime;
   }
   
   public Point getLastPoint()
   {
       return this.lastPoint;
   }
}
