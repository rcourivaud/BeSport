package TagConnexion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.bespoon.uwb.manager.UwbDevice;


public class TagHandler{
	

    private List<TAGDevice> TagDevicesList;
    
	public TagHandler(){
		this.TagDevicesList = new ArrayList<TAGDevice>();
	}
	
	public void addTag(TAGDevice pTag){
		if(!this.TagDevicesList.contains(pTag)){
			this.TagDevicesList.add(pTag);	
		}	
	}
	
	public void removeTag(TAGDevice pTag){
		this.TagDevicesList.remove(pTag);		
	}
	
	public void removeTag(UwbDevice device){
		this.TagDevicesList.remove(this.getTagByDevice(device));
	}
	
	public ArrayList<HashMap<String, String>> getMapForDisplay(){
		ArrayList<HashMap<String, String>> listItem = new ArrayList<HashMap<String, String>>();
        for(TAGDevice vP:this.TagDevicesList){
        	int index = this.TagDevicesList.indexOf(vP);
        	//Log.d("Index" , ""+ index);
        	String position = "";
        	switch(index){
        		case 0:
        			position = "Coin Haut Gauche";
        			break;
        		case 1:
        			position = "Coin Bas Gauche";
        			break;

        		case 2:
        			position = "Coin Bas Droit";
        			break;

        		case 3:
        			position = "Coin Haut Droit";
        			break;

        	}
        	
            HashMap<String,String> map = new HashMap<String,String>();
            String Name = vP.getaTagName();
            map.put("name", Name);
            map.put("position", position);
            map.put("distance", "" + vP.getaTagDistance());
            listItem.add(map);
        }
        return listItem;
	}
	
	public void updateTagDistance(UwbDevice device, float pD){
		this.getTagByDevice(device).updateDistance(pD);		
	}
	
	public int getNumberOfTag(){
		return this.TagDevicesList.size();
	}
	
	public TAGDevice getTagByDevice(UwbDevice device){
		for(TAGDevice pD : this.TagDevicesList){
			if(pD.getMyUwbTag().equals(device)){
				return pD;
			}
		}
		return null;
	}
	
	public boolean containsTAG(UwbDevice device){
		if(getTagByDevice(device)!=null){
			return true;			
		}
		return false;
	}
}
