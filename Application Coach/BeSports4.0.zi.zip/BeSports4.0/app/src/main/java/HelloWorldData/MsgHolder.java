package HelloWorldData;


public final class MsgHolder implements org.omg.CORBA.portable.Streamable
{
  public HelloWorldData.Msg value = null;

  public MsgHolder ()
  {
  }

  public MsgHolder (HelloWorldData.Msg initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = HelloWorldData.MsgHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    HelloWorldData.MsgHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return HelloWorldData.MsgHelper.type ();
  }

}
