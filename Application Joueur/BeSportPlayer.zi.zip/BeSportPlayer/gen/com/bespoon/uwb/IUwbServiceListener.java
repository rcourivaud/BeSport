/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\Users\\rcour\\workspace\\Base_UWB\\BeSportPlayer\\src\\com\\bespoon\\uwb\\IUwbServiceListener.aidl
 */
package com.bespoon.uwb;
public interface IUwbServiceListener extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.bespoon.uwb.IUwbServiceListener
{
private static final java.lang.String DESCRIPTOR = "com.bespoon.uwb.IUwbServiceListener";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.bespoon.uwb.IUwbServiceListener interface,
 * generating a proxy if needed.
 */
public static com.bespoon.uwb.IUwbServiceListener asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.bespoon.uwb.IUwbServiceListener))) {
return ((com.bespoon.uwb.IUwbServiceListener)iin);
}
return new com.bespoon.uwb.IUwbServiceListener.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_onIUwbEnableStateChange:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
this.onIUwbEnableStateChange(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_onIUwbRadioStateChange:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
this.onIUwbRadioStateChange(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_onIUwbDeviceBondingRequest:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onIUwbDeviceBondingRequest(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onIUwbDeviceBondingStateChange:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
int _arg2;
_arg2 = data.readInt();
int _arg3;
_arg3 = data.readInt();
this.onIUwbDeviceBondingStateChange(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
return true;
}
case TRANSACTION_onIUwbDeviceBondingCanceled:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onIUwbDeviceBondingCanceled(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onIUwbDeviceAttachRequest:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onIUwbDeviceAttachRequest(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onIUwbDeviceAttached:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onIUwbDeviceAttached(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onIUwbDeviceDetachRequest:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onIUwbDeviceDetachRequest(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onIUwbDeviceDetached:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onIUwbDeviceDetached(_arg0);
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.bespoon.uwb.IUwbServiceListener
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/**********************  Session callbacks 	*//**
	 * Called whenever the local UWB adapter enable state changes.
     * {@link #Uwb.ENABLE_STATE_OFF},
     * {@link #Uwb.ENABLE_STATE_TURNING_ON},
     * {@link #Uwb.ENABLE_STATE_ON},
     * {@link #Uwb.ENABLE_STATE_TURNING_OFF
	 */
@Override public void onIUwbEnableStateChange(int prevState, int newState) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(prevState);
_data.writeInt(newState);
mRemote.transact(Stub.TRANSACTION_onIUwbEnableStateChange, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called whenever the local UWB adapter Radio state changes.
     * {@link #Uwb.RADIO_STATE_OFF},
     * {@link #STATE_TURNING_ON},
     * {@link #STATE_ON},
     * {@link #STATE_TURNING_OFF
	 */
@Override public void onIUwbRadioStateChange(int prevState, int newState) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(prevState);
_data.writeInt(newState);
mRemote.transact(Stub.TRANSACTION_onIUwbRadioStateChange, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/************************ Bonding Callbacks *//**
	 * Called whenever a device wants to start a bonding process.
	 * @param device the IUwbDevice candidate for bonding
	 */
@Override public void onIUwbDeviceBondingRequest(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_onIUwbDeviceBondingRequest, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called whenever the device bonding state changes.
     * {@link #BOND_NONE},
     * {@link #BOND_BONDING},
     * {@link #BOND_BONDED}.
	 * @param device : the IUwbDevice candidate for bonding
	 * @param prevState : previous bonding state
	 * @param newState : new bonding state
	 * @param errno : more information about the state change mostly error codes when bonding failed
	*/
@Override public void onIUwbDeviceBondingStateChange(int shortAddress, int prevState, int newState, int errno) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
_data.writeInt(prevState);
_data.writeInt(newState);
_data.writeInt(errno);
mRemote.transact(Stub.TRANSACTION_onIUwbDeviceBondingStateChange, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called whenever the device canceled the bonding process.
	 * @param device : the IUwbDevice candidate for bonding
	 */
@Override public void onIUwbDeviceBondingCanceled(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_onIUwbDeviceBondingCanceled, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called whenever a bonded device wants to start a location session with the master.
	 * @param device : the IUwbDevice candidate for attachment
	 */
@Override public void onIUwbDeviceAttachRequest(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_onIUwbDeviceAttachRequest, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called whenever a bonded device started a location session with the master.
	 * @param device : the IUwbDevice candidate for attachment
	 */
@Override public void onIUwbDeviceAttached(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_onIUwbDeviceAttached, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called whenever an attached device wants to leave a location session with the master.
	 * @param device : the IUwbDevice candidate for detachment
	 */
@Override public void onIUwbDeviceDetachRequest(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_onIUwbDeviceDetachRequest, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called whenever an attached device left a location session with the master.
	 * @param device : the IUwbDevice candidate for detachment
	 */
@Override public void onIUwbDeviceDetached(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_onIUwbDeviceDetached, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_onIUwbEnableStateChange = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_onIUwbRadioStateChange = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_onIUwbDeviceBondingRequest = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_onIUwbDeviceBondingStateChange = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_onIUwbDeviceBondingCanceled = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_onIUwbDeviceAttachRequest = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_onIUwbDeviceAttached = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_onIUwbDeviceDetachRequest = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_onIUwbDeviceDetached = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
}
/**********************  Session callbacks 	*//**
	 * Called whenever the local UWB adapter enable state changes.
     * {@link #Uwb.ENABLE_STATE_OFF},
     * {@link #Uwb.ENABLE_STATE_TURNING_ON},
     * {@link #Uwb.ENABLE_STATE_ON},
     * {@link #Uwb.ENABLE_STATE_TURNING_OFF
	 */
public void onIUwbEnableStateChange(int prevState, int newState) throws android.os.RemoteException;
/**
	 * Called whenever the local UWB adapter Radio state changes.
     * {@link #Uwb.RADIO_STATE_OFF},
     * {@link #STATE_TURNING_ON},
     * {@link #STATE_ON},
     * {@link #STATE_TURNING_OFF
	 */
public void onIUwbRadioStateChange(int prevState, int newState) throws android.os.RemoteException;
/************************ Bonding Callbacks *//**
	 * Called whenever a device wants to start a bonding process.
	 * @param device the IUwbDevice candidate for bonding
	 */
public void onIUwbDeviceBondingRequest(int shortAddress) throws android.os.RemoteException;
/**
	 * Called whenever the device bonding state changes.
     * {@link #BOND_NONE},
     * {@link #BOND_BONDING},
     * {@link #BOND_BONDED}.
	 * @param device : the IUwbDevice candidate for bonding
	 * @param prevState : previous bonding state
	 * @param newState : new bonding state
	 * @param errno : more information about the state change mostly error codes when bonding failed
	*/
public void onIUwbDeviceBondingStateChange(int shortAddress, int prevState, int newState, int errno) throws android.os.RemoteException;
/**
	 * Called whenever the device canceled the bonding process.
	 * @param device : the IUwbDevice candidate for bonding
	 */
public void onIUwbDeviceBondingCanceled(int shortAddress) throws android.os.RemoteException;
/**
	 * Called whenever a bonded device wants to start a location session with the master.
	 * @param device : the IUwbDevice candidate for attachment
	 */
public void onIUwbDeviceAttachRequest(int shortAddress) throws android.os.RemoteException;
/**
	 * Called whenever a bonded device started a location session with the master.
	 * @param device : the IUwbDevice candidate for attachment
	 */
public void onIUwbDeviceAttached(int shortAddress) throws android.os.RemoteException;
/**
	 * Called whenever an attached device wants to leave a location session with the master.
	 * @param device : the IUwbDevice candidate for detachment
	 */
public void onIUwbDeviceDetachRequest(int shortAddress) throws android.os.RemoteException;
/**
	 * Called whenever an attached device left a location session with the master.
	 * @param device : the IUwbDevice candidate for detachment
	 */
public void onIUwbDeviceDetached(int shortAddress) throws android.os.RemoteException;
}
