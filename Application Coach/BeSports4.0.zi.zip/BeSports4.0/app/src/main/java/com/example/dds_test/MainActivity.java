package com.example.dds_test;

import android.annotation.TargetApi;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.omg.dds.core.ServiceEnvironment;
import org.omg.dds.core.event.DataAvailableEvent;
import org.omg.dds.core.event.LivelinessChangedEvent;
import org.omg.dds.core.event.RequestedDeadlineMissedEvent;
import org.omg.dds.core.event.RequestedIncompatibleQosEvent;
import org.omg.dds.core.event.SampleLostEvent;
import org.omg.dds.core.event.SampleRejectedEvent;
import org.omg.dds.core.event.SubscriptionMatchedEvent;
import org.omg.dds.domain.DomainParticipant;
import org.omg.dds.pub.DataWriter;
import org.omg.dds.sub.DataReader;
import org.omg.dds.sub.DataReaderListener;
import org.omg.dds.sub.Sample;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

import HelloWorldData.Msg;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private String TAG = "MainActivity";

    private Drawable aPLayerDrawable;
    private Team myTeam, opponentTeam;
    private Boolean showName = true;  //Afficher ou non le nom des joueurs
    private Boolean ableToDraw = false; //Possibilité de dessiner

    private int background = 0;


    // attributs pour DDS
    private DomainParticipant dp;
    private DataReader<Msg> MsgReader;
    private DataWriter<Msg> MsgWriter; //moi je n'utilise pas ca
    private String aStringRecup ="Nicolas-5-1-50-50-30-2-40"; //"nom-numero-équipe-x-y-z-vitesse-distance"
    private ArrayList<String> aListString;
    private int idTel = 1;


    public SimpleAdapter mSchedule, mSchedule2;

    //provisoire
    private TextView reception;
    private TextView envoi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.initMainActivityInternPlusProprement();
        this.reception = (TextView) findViewById(R.id.reception);
        this.envoi = (TextView) findViewById(R.id.envoi);
        this.initDDS();
        this.initTeam();


        /*Player p1 = new Player("Nico", 5, 70, 70, 34.68, 1.23, 132.89);
        Player p2 = new Player("Alex", 2, 30, 25, 22.34, 0.39, 81.60);
        Player p3 = new Player("Rapha", 4, 10, 20, 20.23, 1.28, 120.62);
        Player p4 = new Player("Claudia", 1, 50, 75, 22.34, 0.22, 00.25);
        Player p5 = new Player("Chambo", 3, 90, 25, 00.34, 1.09, 00.39);
        this.myTeam.addPlayer(p1);
        this.myTeam.addPlayer(p2);
        this.myTeam.addPlayer(p3);
        this.opponentTeam.addPlayer(p4);
        this.opponentTeam.addPlayer(p5);*/


        this.updateAdapter1();
        this.updateAdapter2();

    }

    public Team getMyTeam() {
        return this.myTeam;
    }
    public Team getOpponentTeam() {
        return this.opponentTeam;
    }


    public Drawable getaPLayerDrawable() {
        if (this.aPLayerDrawable == null) {
            this.aPLayerDrawable = this.getResources().getDrawable(R.drawable.player);
        }
        return this.aPLayerDrawable;
    }

    public void setShowName(Boolean showName) {
        this.showName = showName;
    }
    public Boolean getShowName() {
        return showName;
    }


    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public void enableDraw(View v){
        Log.d(TAG, "enableDraw");
        this.setAbleToDraw();
        if(this.ableToDraw) {
            v.setBackground(this.getResources().getDrawable(R.drawable.drawing));
        }
        else {
            v.setBackground(this.getResources().getDrawable(R.drawable.draw));
        }
    }

    public void refresh(View V){
        Log.d(TAG, "refresh");
        //A compléter
        RelativeLayout drawingPanel = (RelativeLayout) this.findViewById(R.id.drawingPanel);
        Fragment myFieldFrag = new FieldFragment();
        Bundle bundle = new Bundle();

        bundle.putInt("background", this.background);
        drawingPanel.setVisibility(View.INVISIBLE);
        myFieldFrag.setArguments(bundle);

        FragmentManager fragmentManager = this.getFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.fragment_container, myFieldFrag);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    public void screenShot(View v){
        Log.d(TAG, "screeShot");

        Date now = new Date();
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);

        try {
            File directory = new File(Environment.getExternalStorageDirectory().toString() + "/besports/");
            directory.mkdirs();
            String mPath = ""+ now + ".png";

            // create bitmap screen capture
            View v1 = getWindow().getDecorView().getRootView();
            v1.setDrawingCacheEnabled(true);
            Bitmap bitmap = Bitmap.createBitmap(v1.getDrawingCache());
            v1.setDrawingCacheEnabled(false);

            File imageFile = new File(directory, mPath);

            FileOutputStream outputStream = new FileOutputStream(imageFile);
            int quality = 100;
            bitmap.compress(Bitmap.CompressFormat.PNG, quality, outputStream);
            outputStream.flush();
            outputStream.close();

//            openScreenshot(imageFile);
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }



    private void openScreenshot() {
        //Pas du tout stable

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        Uri uri = Uri.parse(Environment.getExternalStorageDirectory().getPath() + "/besports/");
        intent.setDataAndType(uri, "*/*");
        startActivity(Intent.createChooser(intent, "Open folder"));
    }

    public Boolean getAbleToDraw() {
        return this.ableToDraw;
    }
    public void setAbleToDraw() {
        this.ableToDraw = !this.ableToDraw;
    }

    private void initMainActivityInternPlusProprement() {
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            this.setShowName(!this.showName);

            /*Log.d(TAG, aStringRecup);
            this.MsgWriter = ((ChatApplication) getApplication()).getWriter();

            Random r = new Random();
            int equipe = r.nextInt(2)+1;
            int upp = r.nextInt(6)+1;
            int positionFactice = r.nextInt(100);
            int positionFacticey = r.nextInt(100);
            int vitesse = r.nextInt(20);
            this.aStringRecup = "Nicolas"+upp+"-5-"+equipe+"-"+positionFactice+"-"+positionFacticey+"-30-"+vitesse+"-40";
            Log.d(TAG, "Position = "+positionFactice);


            try {
                this.MsgWriter.write(new Msg(idTel, this.aStringRecup));
                this.envoi.setText("Message envoyé...");

            } catch (TimeoutException te) {
                this.envoi.setText("Message non envoyé ...");
            }*/

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        RelativeLayout drawingPanel = (RelativeLayout) this.findViewById(R.id.drawingPanel);
        int id = item.getItemId();

        Fragment myFieldFrag = new FieldFragment();
        Bundle bundle = new Bundle();

        switch (id) {
            case R.id.basketId:
                this.background = 1;
                this.aPLayerDrawable = this.getResources().getDrawable(R.drawable.basketball_player);
                bundle.putInt("background", this.background);
                break;
            case R.id.footballId:
                this.background = 2;
                this.aPLayerDrawable = this.getResources().getDrawable(R.drawable.player);
                bundle.putInt("background", this.background);
                break;
            case R.id.hockeyId:
                this.background = 3;
                this.aPLayerDrawable = this.getResources().getDrawable(R.drawable.hockey_player);
                bundle.putInt("background", this.background);
                break;
            case R.id.tennisId:
                this.background = 4;
                this.aPLayerDrawable = this.getResources().getDrawable(R.drawable.tennis);
                bundle.putInt("background", this.background);
                break;
            case R.id.badmintonId:
                this.background = 5;
                this.aPLayerDrawable = this.getResources().getDrawable(R.drawable.tennis);
                bundle.putInt("background", this.background);
                break;
            case R.id.handballId:
                this.background = 6;
                this.aPLayerDrawable = this.getResources().getDrawable(R.drawable.player);
                bundle.putInt("background", this.background);
                break;

            case R.id.stat_id:
                this.background = 0;
                this.aPLayerDrawable = null;
                break;
            case R.id.user_id:
                this.background = 0;
                this.aPLayerDrawable = null;
                this.openScreenshot();
                return true;

            default:
                this.background = 0;
                this.aPLayerDrawable = null;
                break;
        }
        drawingPanel.setVisibility(View.INVISIBLE);
        myFieldFrag.setArguments(bundle);



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);

        //Fragment gestion
        FragmentManager fragmentManager = this.getFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        if (background ==0 || this.aPLayerDrawable == null) {
            myFieldFrag = new MyStatsFragment();
        }
        transaction.replace(R.id.fragment_container, myFieldFrag);
        transaction.addToBackStack(null);
        transaction.commit();

        return true;
    }


    private void initTeam(){
        this.myTeam = new Team("Domicile");
        //this.myTeam.createTestTeam();
        Random rnd = new Random();
        int color1 = Color.rgb(256, rnd.nextInt(256), rnd.nextInt(256));
        this.myTeam.setTeamColor(color1);

        this.opponentTeam = new Team("Extérieur");
        //this.opponentTeam.createTestTeam();
        int color2 = Color.rgb(0, rnd.nextInt(256), rnd.nextInt(256));
        this.opponentTeam.setTeamColor(color2);
    }

    public ArrayList<String> extractString(){
        String[] stringTab = this.aStringRecup.split("-");
        ArrayList<String> stringArray = new ArrayList<>();
        for(String str:stringTab){
            stringArray.add(str);
        }
        return stringArray;
    }

    public void updateAdapter1(){
        ArrayList<HashMap<String, String>> listItemPerso =  myTeam.getListForDisplay();
        this.mSchedule = new SimpleAdapter (this, listItemPerso, R.layout.display_player_stat,
                new String[] {"img", "playername", "vitesse", "hauteur", "distanceparcourue", "playernumero"},
                new int[] {R.id.img, R.id.playername, R.id.vitesse, R.id.hauteur, R.id.distanceparcourue, R.id.numero});
    }

    public void updateAdapter2(){
        ArrayList<HashMap<String, String>> listItemOpponent =  opponentTeam.getListForDisplay();
        this.mSchedule2 = new SimpleAdapter (this, listItemOpponent, R.layout.display_player_stat_otherteam,
                new String[] {"img", "playername", "vitesse", "hauteur", "distanceparcourue", "playernumero"},
                new int[] {R.id.img, R.id.playername, R.id.vitesse, R.id.hauteur, R.id.distanceparcourue, R.id.numero});
    }


    private void initDDS(){
        this.MsgWriter = ((ChatApplication) getApplication()).getWriter();

        System.setProperty(ServiceEnvironment.IMPLEMENTATION_CLASS_NAME_PROPERTY, Config.DDS_BOOTSTRAP_CLASS);
        this.MsgReader = ((ChatApplication) getApplication()).getReader();
        this.MsgReader.setListener(new DataReaderListener<Msg>() {
            @Override
            public void onDataAvailable(DataAvailableEvent<Msg> dataAvailableEvent) {


                StringBuilder vStr = new StringBuilder("");
                Sample.Iterator<Msg> it = dataAvailableEvent.getSource().take();
                while(it.hasNext()) {
                    Msg notif = it.next().getData();
                    vStr.append( notif.message);
                }
                aStringRecup = vStr.toString();



                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        reception.setText("Message recu : ''"+aStringRecup+"''");
                        Log.d(TAG, "Message recu : ''"+aStringRecup+"''");
                        aListString = extractString();

                        /*String string= "aListString = ";
                        for(String str : aListString){
                            string += str;
                            string += " - ";
                        }
                        Log.d(TAG, string);*/

                        try{
                            String name = aListString.get(0);
                            int numero = Integer.parseInt(aListString.get(1));
                            int equipe = Integer.parseInt(aListString.get(2));
                            int x = Integer.parseInt(aListString.get(3));
                            int y = Integer.parseInt(aListString.get(4));

                            double z;
                            try{
                                z = Double.parseDouble(aListString.get(5));
                            } catch(Exception e){
                                z = 0.0;
                            }

                            double vitesse;
                            try{
                                vitesse = Double.parseDouble(aListString.get(6));
                            } catch(Exception e){
                                vitesse = 0.0;
                            }

                            double distance;
                            try{
                                distance = Double.parseDouble(aListString.get(7));

                            } catch(Exception e){
                                distance = 0.0;
                            }
                            Log.d(TAG,name+" "+numero+" "+equipe+" "+x+" "+y+" "+z+" "+vitesse+" "+distance);



                            if(equipe == 1){
                                myTeam.updateNameList();
                                if(!myTeam.getaPlayerNameList().contains(name)){
//                                Log.d(TAG, "mon equipe ne contient pas le joueur : "+name);
                                    Player player = new Player(name, numero, x, y, z, vitesse, distance);
                                    myTeam.addPlayer(player); //add player avec nom et numéro
                                }
                                else{
//                                Log.d(TAG, "mon equipe contient le joueur : "+name);
                                    Player p = myTeam.getPlayerFromTeam(name);
                                    p.updatePlayerFromTag(x, y, z, distance, vitesse);
                                }
                                if(MyStatsFragment.maListViewPerso != null){
                                    updateAdapter1();
                                    MyStatsFragment.maListViewPerso.setAdapter(mSchedule);
                                    if(mSchedule.getCount() > 3){
                                        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) MyStatsFragment.maListViewPerso.getLayoutParams();
                                        lp.height = 500;
                                        MyStatsFragment.maListViewPerso.setLayoutParams(lp);

                                    }
                                }

                            }
                            else if(equipe == 2){
                                opponentTeam.updateNameList();
                                if(!opponentTeam.getaPlayerNameList().contains(name)){
                                    Player player = new Player(name, numero, x, y, z, vitesse, distance);
                                    opponentTeam.addPlayer(player);
                                }
                                else {
                                    Player p = opponentTeam.getPlayerFromTeam(name);
                                    p.updatePlayerFromTag(x, y, z, distance, vitesse);
                                }
                                if(MyStatsFragment.opponentTeamView != null) {
                                    updateAdapter2();
                                    MyStatsFragment.opponentTeamView.setAdapter(mSchedule2);
                                }
                            }
                        }
                        catch(Exception error){
                            Log.e(TAG, error.toString());
                        }


                    }
                });

            }

            @Override
            public void onRequestedDeadlineMissed(RequestedDeadlineMissedEvent<Msg> requestedDeadlineMissedEvent) {

            }

            @Override
            public void onRequestedIncompatibleQos(RequestedIncompatibleQosEvent<Msg> requestedIncompatibleQosEvent) {

            }

            @Override
            public void onSampleRejected(SampleRejectedEvent<Msg> sampleRejectedEvent) {

            }

            @Override
            public void onLivelinessChanged(LivelinessChangedEvent<Msg> livelinessChangedEvent) {

            }

            @Override
            public void onSubscriptionMatched(SubscriptionMatchedEvent<Msg> subscriptionMatchedEvent) {

            }

            @Override
            public void onSampleLost(SampleLostEvent<Msg> sampleLostEvent) {

            }
        });
    }

   }
