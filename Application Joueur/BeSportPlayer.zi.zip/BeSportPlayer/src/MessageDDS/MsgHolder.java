package MessageDDS;


public final class MsgHolder implements org.omg.CORBA.portable.Streamable
{
  public MessageDDS.Msg value = null;

  public MsgHolder ()
  {
  }

  public MsgHolder (MessageDDS.Msg initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = MessageDDS.MsgHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    MessageDDS.MsgHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return MessageDDS.MsgHelper.type ();
  }

}
