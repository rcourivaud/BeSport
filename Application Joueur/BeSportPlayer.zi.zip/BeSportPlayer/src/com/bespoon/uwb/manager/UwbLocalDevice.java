package com.bespoon.uwb.manager;

import android.os.RemoteException;

import com.bespoon.uwb.IUwbDevice;

public class UwbLocalDevice extends UwbDevice {
    /*package*/ UwbLocalDevice(IUwbDevice from) throws RemoteException {
        super(from);
    }

    /**
     * Get the device moving state.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
//    public int getMovingState() {
//        try {
//            return mIUwbDevice.getMovingState();
//        } catch (RemoteException e) {
//            e.printStackTrace();
//            // TODO: use enumeration
//            return 0;
//        }
//    }

    /**
     * Set if the device is moving or not .
     * Only available for local adapter
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
//    public void setMovingState(int moveState) {
//        try {
//            mIUwbDevice.setMovingState(moveState);
//        } catch (RemoteException e) {
//            e.printStackTrace();
//        }
//    }

    /**
     * Set the Local adapter current profile.
     *
     * <p>This is an asynchronous call, it will return immediately.
     * Listen to {@link #onLocationProfilechanged()} to be notified when
     * the profile changed  and its result.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     * @param locationProfile : TYPE_TAG,TYPE_BASE etc..
     * @hide
     */
    public int setLocationProfile(int locationProfile) {
        try {
            return mIUwbDevice.setLocationProfile(locationProfile);
        } catch (RemoteException e) {
            e.printStackTrace();
            // TODO: ?
            return 0;
        }
    }
}
