package com.example.dds_test;

import android.graphics.Point;

import java.util.HashMap;

/**
 * Created by Raphael on 19/12/2015.
 */
public class Player {
    private String aName;
    private int aNumero;

    private int aXpos;
    private int aYpos;

    private double aVitesse;
    private double aHauteur;
    private double aDistance;

    //Affichage
    private Point position;


    public Player(int pNum){
        this.aName=""+pNum;
        this.aNumero=pNum;
        this.aVitesse=0;
        this.aHauteur=0;
        this.aDistance=0;
        this.aXpos=0;
        this.aYpos=0;
        this.position = new Point(aXpos, aYpos);

    }

    public Player(String pName, int pNum){
        this.aName=pName;
        this.aNumero=pNum;
        this.aVitesse=0;
        this.aHauteur=0;
        this.aDistance=0;
        this.aXpos=0;
        this.aYpos=0;
    }

    public Player(String pName, int pNumero, int pX, int pY, double pVitesse, double pHauteur, double pDistance){
        this.aName=pName;
        this.aNumero=pNumero;
        this.aVitesse=pVitesse;
        this.aHauteur=pHauteur;
        this.aDistance=pDistance;
        this.aXpos=pX;
        this.aYpos=pY;
        this.position = new Point(aXpos, aYpos);
    }

    public void updatePlayerFromTag(int x, int y, double z, double distance, double vitesse){
        this.aVitesse=vitesse;
        this.aHauteur=z;
        this.aDistance=distance;
        this.aXpos=x;
        this.aYpos=y;
        this.position.set(this.aXpos, this.aYpos);
    }


    public HashMap<String, String> getMapForDisplay(){
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("playername", this.aName);
        map.put("playernumero", ""+this.aNumero);
        map.put("vitesse", "" + this.aVitesse);
        map.put("hauteur", "" + this.aHauteur);
        map.put("distanceparcourue", "" + this.aDistance);
        map.put("img", String.valueOf(R.drawable.user));
        return map;
    }

    @Override
    public String toString(){
        return "Player : " + this.aName + " , " + this.aNumero + " , " + this.aVitesse + " , " + this.aDistance + " , " + this.aHauteur + ".\n";
    }

    public String getaName() {
        return aName;
    }

    public int getaNumero() {
        return aNumero;
    }

    public double getaXpos() {
        return aXpos;
    }

    public double getaYpos() {
        return aYpos;
    }

    public double getaVitesse() {
        return aVitesse;
    }

    public double getaHauteur() {
        return aHauteur;
    }

    public double getaDistance() {
        return aDistance;
    }

    public Point getPosition() { return this.position; }

    public void setaName(String aName) {
        this.aName = aName;
    }

    public void setaNumero(int aNumero) {
        this.aNumero = aNumero;
    }

    public void setaXpos(int aXpos) {
        this.aXpos = aXpos;
    }

    public void setaYpos(int aYpos) {
        this.aYpos = aYpos;
    }

    public void setaVitesse(double aVitesse) {
        this.aVitesse = aVitesse;
    }

    public void setaHauteur(double aHauteur) {
        this.aHauteur = aHauteur;
    }

    public void setaDistance(double aDistance) {
        this.aDistance = aDistance;
    }

    public void setPosition(int x, int y) { this.position.x = x; this.position.y = y; }

}
