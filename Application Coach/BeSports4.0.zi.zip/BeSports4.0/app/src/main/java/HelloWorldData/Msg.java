package HelloWorldData;


import org.opensplice.mobile.dcps.keys.KeyList;

@KeyList(
    topicType = "Msg",
    keys = {"userID"}
)
public final class Msg implements org.omg.CORBA.portable.IDLEntity
{
  public int userID = (int)0;

  // User ID
  public String message = null;

  public Msg ()
  {
  } // ctor

  public Msg (int _userID, String _message)
  {
    userID = _userID;
    message = _message;
  } // ctor

} // class Msg
