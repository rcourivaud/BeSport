/**
 *                          OpenSplice Mobile
 *
 *    This software and documentation are Copyright 2010 to 2013 PrismTech
 *    Limited and its licensees. All rights reserved. See file:
 *
 *                           docs/LICENSE.html
 *
 *    for full copyright notice and license terms.
 */
package com.example.dds_test;

import android.app.Application;

import org.omg.dds.core.ServiceEnvironment;
import org.omg.dds.domain.DomainParticipant;
import org.omg.dds.domain.DomainParticipantFactory;
import org.omg.dds.pub.DataWriter;
import org.omg.dds.pub.Publisher;
import org.omg.dds.sub.DataReader;
import org.omg.dds.sub.Subscriber;
import org.omg.dds.topic.Topic;

import HelloWorldData.Msg;

/**
 * Specialization of Android's {@link Application} class to initialize DDS
 * at creation of the application, and close it at termination.
 */
public class ChatApplication extends Application {

    // the DDS DomainParticipant
    private DomainParticipant dp;
    // the DDS DataReader for ChatMessage type
    private DataReader<Msg> dr;
    // the DDS DataWriter for ChatMessage type
    private DataWriter <Msg> dw;


    @Override
    public void onCreate() {
        super.onCreate();

        // Configure DDS ServiceEnvironment class to be OpenSplice Mobile
        System.setProperty(ServiceEnvironment.IMPLEMENTATION_CLASS_NAME_PROPERTY,
            Config.DDS_BOOTSTRAP_CLASS);

        // Create a DDS ServiceEnvironment
        ServiceEnvironment env = ServiceEnvironment.createInstance(
            this.getClass().getClassLoader());

        // Get the DomainParticipantFactory singleton
        DomainParticipantFactory dpf =
            DomainParticipantFactory.getInstance(env);

        // Create a DomainParticipant on DomainID
        dp = dpf.createParticipant(Config.DDS_DOMAIN_ID);

        Topic<Msg> topic = dp.createTopic(Config.DDS_TOPIC_NAME, Msg.class);

        // Create a Publisher and a Subscriber (with default QoS)
        Publisher pub = dp.createPublisher();
        Subscriber sub = dp.createSubscriber();

        dw = pub.createDataWriter(topic);
        dr = sub.createDataReader(topic);
    }

    /**
     * @return the DDS DataReader
     */
    public DataReader<Msg> getReader() {
        return this.dr;
    }

    /**
     * @return the DDS DataWriter
     */
    public DataWriter<Msg> getWriter() {
        return this.dw;
    }


    @Override
    public void onTerminate() {
        super.onTerminate();
        // Close the DDS DomainParticipant and all its child entities
        this.dp.close();
    }
}
