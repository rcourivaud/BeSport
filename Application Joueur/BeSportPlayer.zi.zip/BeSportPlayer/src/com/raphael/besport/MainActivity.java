package com.raphael.besport;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import edu.esiee.localisation.R;

import org.omg.dds.core.ServiceEnvironment;
//import org.omg.dds.domain.DomainParticipant;
import org.omg.dds.pub.DataWriter;
//import org.omg.dds.sub.DataReader;

import java.util.concurrent.TimeoutException;

import com.bespoon.uwb.manager.UwbDevice;
import com.bespoon.uwb.manager.UwbManager;

import MessageDDS.Msg;
import TagConnexion.TagHandler;
import algorithmes.Joueur;
import algorithmes.Point;

public class MainActivity extends Activity {

	
	//Pour l'UWB
    private UwbManager mUWBManager;
    public List <UwbDevice> mUwbAttachedDevices;   
    public TagHandler myTagHandler;    
    int nbAttachedDevice=0;
    
    //UWB Listener    
    private UWBDeviceHelper myUWBDeviceListener;
    private UWBManagerHelper myUWBManagerListener;

    
	public Joueur myPlayer;

	public Double aLargeur ;
	public Double aLongueur ;
	
	public ArrayList<Double> aTabDist;
	private ListView mylistView; 
	
    // attributs pour DDS
    //private DomainParticipant dp;
    
    //Pour tester
    //private DataReader<Msg> MsgReader;
    private DataWriter<Msg> MsgWriter; 
    private int idTel = 1;


private static final String TAG = "MonActivity";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mUwbAttachedDevices = new ArrayList<UwbDevice>();
        mUWBManager = new UwbManager();
        
        Bundle extras = getIntent().getExtras();
        String vPlayerName = "";
        String vPlayerNum = "";
        String vPlayerTeam = "";
        if (extras != null) {
        	vPlayerName = extras.getString("name");
        	vPlayerNum = extras.getString("number");
        	this.aLargeur = extras.getDouble("largeur");
        	this.aLongueur = extras.getDouble("longueur");
        	vPlayerTeam = "" + extras.getInt("team");
        }
        
        Point aPointTL = new Point();
        Point aPointTR = new Point(this.aLargeur*100,0.0,0.0);
        Point aPointBL = new Point(0.0,this.aLongueur*100,0.0);
        Point aPointBR = new Point(this.aLargeur*100,this.aLongueur*100,0.5);
        
        ArrayList<Point> pTabPoint = new ArrayList<Point>();
        pTabPoint.add(aPointTL);
        pTabPoint.add(aPointBL);
        pTabPoint.add(aPointBR);
        pTabPoint.add(aPointTR);
        
        myPlayer = new Joueur(vPlayerName, vPlayerNum, vPlayerTeam, pTabPoint, this);
        
        this.aTabDist = new ArrayList<Double>();
        this.aTabDist.add(0.0);
        this.aTabDist.add(0.0);
        this.aTabDist.add(0.0);
        this.aTabDist.add(0.0);
        
        myTagHandler = new TagHandler(); 
       this.updateTagInfos();
       this.updatePlayerInfos();
       
       ((TextView)findViewById(R.id.playerNameView)).setText("Nom : " +  this.myPlayer.getaName());
       ((TextView)findViewById(R.id.playerNumView)).setText("Num�ro : "  + this.myPlayer.getaNum());
       String vPlayerTeamToDisplay = "";
       if(this.myPlayer.getaTeam().equals("1")){
    	   vPlayerTeamToDisplay = "Home";
       }
       else{
    	   vPlayerTeamToDisplay = "Away";

       }
       ((TextView)findViewById(R.id.teamView)).setText("Team : " +  vPlayerTeamToDisplay);
       //this.idTel = Integer.parseInt(this.myPlayer.getaTeam()+ this.myPlayer.getaNum());
       this.initDDS();
       
       this.myUWBDeviceListener = new UWBDeviceHelper(this);
       this.myUWBManagerListener = new UWBManagerHelper(this);
	}
	
	public void onClickBouton(View v){
		mUWBManager.registerUWBManagerListener(this.myUWBManagerListener);
        mUWBManager.create(this);
    	mUWBManager.enable();
    	Log.i(TAG,"UWBMAnger on");
	}
	public void onClicStop(View v){
		this.mUWBManager.unregisterUWBManagerListener(this.myUWBManagerListener);
		this.mUWBManager.disable();
		this.mUWBManager.destroy();
	}
	
    public String getDeviceIdentity(UwbDevice device) {
	        if (device.getName() != null) {
	            return device.getName();
	        }
	        else {
	            return String.valueOf(device.getShortAddress());
	        }
	    }  
   
    public void updateTagInfos(){
    	ListView maListViewPerso = (ListView) findViewById(R.id.malistTagInfo);
        ArrayList<HashMap<String, String>> listItem = this.myTagHandler.getMapForDisplay();
        SimpleAdapter mSchedule = new SimpleAdapter(this.getBaseContext(), listItem, R.layout.simple_tag_info,
                new String[] {"name", "distance", "position"}, new int[] {R.id.name, R.id.distance, R.id.position});
        maListViewPerso.setAdapter(mSchedule);
    }
    
    public  void updatePlayerInfos(){    	
    	ListView maListViewPerso = (ListView) findViewById(R.id.malistStats);
        ArrayList<HashMap<String, String>> listItem = this.myPlayer.getMapForDisplay();
        SimpleAdapter mSchedule = new SimpleAdapter(this.getBaseContext(), listItem, R.layout.simple_player_stat,
                new String[] {"stat", "value"}, new int[] {R.id.stat, R.id.value});
        maListViewPerso.setAdapter(mSchedule);
    	
    }
    
    private void initDDS(){
        this.MsgWriter = ((ChatApplication) getApplication()).getWriter();

        System.setProperty(ServiceEnvironment.IMPLEMENTATION_CLASS_NAME_PROPERTY, Config.DDS_BOOTSTRAP_CLASS);

        //this.MsgReader = ((ChatApplication) getApplication()).getReader();

        /*this.MsgReader.setListener(new DataReaderListener<Msg>() {
            @Override
            public void onDataAvailable(DataAvailableEvent<Msg> dataAvailableEvent) {

                StringBuilder vStr = new StringBuilder("");

                Sample.Iterator<Msg> it = dataAvailableEvent.getSource().take();

                while(it.hasNext()) {
                    Msg notif = it.next().getData();
                    vStr.append( notif.message);
                }
                String myString = vStr.toString();
                Log.d(TAG, "DataAvailable");
                Log.d(TAG, "String : " + myString);
            }

            @Override
            public void onRequestedDeadlineMissed(RequestedDeadlineMissedEvent<Msg> requestedDeadlineMissedEvent) {

            }

            @Override
            public void onRequestedIncompatibleQos(RequestedIncompatibleQosEvent<Msg> requestedIncompatibleQosEvent) {

            }

            @Override
            public void onSampleRejected(SampleRejectedEvent<Msg> sampleRejectedEvent) {

            }

            @Override
            public void onLivelinessChanged(LivelinessChangedEvent<Msg> livelinessChangedEvent) {

            }

            @Override
            public void onSubscriptionMatched(SubscriptionMatchedEvent<Msg> subscriptionMatchedEvent) {

            }

            @Override
            public void onSampleLost(SampleLostEvent<Msg> sampleLostEvent) {

            }
        });*/
    }
    
    public void sendStringToDDS(String pS){
        try {
            this.MsgWriter.write(new Msg(idTel, pS));
            Log.d(TAG,"Message envoy�...");

        } catch (TimeoutException te) {
            Log.d(TAG,"Message non envoy� ...");
        }
    }
    
    public void sendTest(View pV){
    	Log.d(TAG, "sendTest");
    	String vS = this.myPlayer.createStringToSend();
    	Toast.makeText(this,vS, Toast.LENGTH_LONG).show();
    	this.sendStringToDDS(this.myPlayer.createStringToSend());
    	
    }
    
    public UWBDeviceHelper getUwbDeviceListener(){
    	return this.myUWBDeviceListener;
    }
}
