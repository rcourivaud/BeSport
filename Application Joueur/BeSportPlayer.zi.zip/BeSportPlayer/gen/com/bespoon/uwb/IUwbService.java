/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\Users\\rcour\\workspace\\Base_UWB\\BeSportPlayer\\src\\com\\bespoon\\uwb\\IUwbService.aidl
 */
package com.bespoon.uwb;
public interface IUwbService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.bespoon.uwb.IUwbService
{
private static final java.lang.String DESCRIPTOR = "com.bespoon.uwb.IUwbService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.bespoon.uwb.IUwbService interface,
 * generating a proxy if needed.
 */
public static com.bespoon.uwb.IUwbService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.bespoon.uwb.IUwbService))) {
return ((com.bespoon.uwb.IUwbService)iin);
}
return new com.bespoon.uwb.IUwbService.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_registerListener:
{
data.enforceInterface(DESCRIPTOR);
com.bespoon.uwb.IUwbServiceListener _arg0;
_arg0 = com.bespoon.uwb.IUwbServiceListener.Stub.asInterface(data.readStrongBinder());
this.registerListener(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_unregisterListener:
{
data.enforceInterface(DESCRIPTOR);
com.bespoon.uwb.IUwbServiceListener _arg0;
_arg0 = com.bespoon.uwb.IUwbServiceListener.Stub.asInterface(data.readStrongBinder());
this.unregisterListener(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_enable:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.enable();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_disable:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.disable();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getEnableState:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getEnableState();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_enableRadio:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.enableRadio();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_disableRadio:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.disableRadio();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getRadioState:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getRadioState();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getScanMode:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getScanMode();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_setScanMode:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
boolean _result = this.setScanMode(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_startBonding:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
boolean _result = this.startBonding(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_startBondingOutOfBand:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
byte[] _arg2;
_arg2 = data.createByteArray();
boolean _result = this.startBondingOutOfBand(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_acceptBondingRequest:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.acceptBondingRequest(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_declineBondingRequest:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.declineBondingRequest(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_cancelBondingProcess:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
boolean _result = this.cancelBondingProcess(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_removeBond:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
boolean _result = this.removeBond(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_acceptAttachRequest:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.acceptAttachRequest(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_declineAttachRequest:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.declineAttachRequest(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_getBondedDevices:
{
data.enforceInterface(DESCRIPTOR);
int[] _result = this.getBondedDevices();
reply.writeNoException();
reply.writeIntArray(_result);
return true;
}
case TRANSACTION_getAttachedDevices:
{
data.enforceInterface(DESCRIPTOR);
int[] _result = this.getAttachedDevices();
reply.writeNoException();
reply.writeIntArray(_result);
return true;
}
case TRANSACTION_getDevice:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
com.bespoon.uwb.IUwbDevice _result = this.getDevice(_arg0);
reply.writeNoException();
reply.writeStrongBinder((((_result!=null))?(_result.asBinder()):(null)));
return true;
}
case TRANSACTION_getLocalDevice:
{
data.enforceInterface(DESCRIPTOR);
com.bespoon.uwb.IUwbDevice _result = this.getLocalDevice();
reply.writeNoException();
reply.writeStrongBinder((((_result!=null))?(_result.asBinder()):(null)));
return true;
}
case TRANSACTION_addManualBond:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.addManualBond(_arg0);
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.bespoon.uwb.IUwbService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public void registerListener(com.bespoon.uwb.IUwbServiceListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_registerListener, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void unregisterListener(com.bespoon.uwb.IUwbServiceListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_unregisterListener, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
//*********************************************************************************
//***************************   Session control  **********************************
//*********************************************************************************
/**
     * Turn on the local UWB adapter&mdash;do not use without explicit
     * user action to turn on UWB Location.
     * <p>This powers on the underlying UWB hardware, starts UWB radio and starts all
     * UWB Location system services.
     * <p class="caution"><strong>UWB should never be enabled without
     * direct user consent</strong>. If you want to turn on UWB in order
     * to create a wireless network, you should use the {@link
     * #ACTION_REQUEST_ENABLE} Intent, which will raise a dialog that requests
     * user permission to turn on UWB Location. The {@link #enable()} method is
     * provided only for applications that include a user interface for changing
     * system settings, such as a "power manager" app.</p>
     * <p>This is an asynchronous call: it will return immediately, and
     * clients should listen for {@link #onUWBStateChange()}
     * to be notified of subsequent adapter state changes. If this call returns
     * true, then the adapter state will immediately transition from {@link
     * #STATE_OFF} to {@link #STATE_TURNING_ON}, and some time
     * later transition to either {@link #STATE_OFF} or {@link
     * #STATE_ON}. If this call returns false then there was an
     * immediate problem that will prevent the adapter from being turned on -
     * such as Airplane mode, or the adapter is already turned on.
     * <p>Requires the {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * permission
     *
     * @return true to indicate adapter startup has begun, or false on
     *         immediate error
     */
@Override public boolean enable() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_enable, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Turn off the local UWB adapter&mdash;do not use without explicit
     * user action to turn off UWB.
     * <p>This gracefully shuts down UWB radio, all UWB connections, stops UWB
     * system services, and powers down the underlying UWB hardware.
     * <p class="caution"><strong>UWB should never be disabled without
     * direct user consent</strong>. The {@link #disable()} method is
     * provided only for applications that include a user interface for changing
     * system settings, such as a "power manager" app.</p>
     * <p>This is an asynchronous call: it will return immediately, and
     * clients should listen for {@link #onUWBStateChange()}
     * to be notified of subsequent adapter state changes. If this call returns
     * true, then the adapter state will immediately transition from {@link
     * #STATE_ON} to {@link #STATE_TURNING_OFF}, and some time
     * later transition to either {@link #STATE_OFF} or {@link
     * #STATE_ON}. If this call returns false then there was an
     * immediate problem that will prevent the adapter from being turned off -
     * such as the adapter already being turned off.
     * <p>Requires the {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * permission
     *
     * @return true to indicate adapter shutdown has begun, or false on
     *         immediate error
     */
@Override public boolean disable() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_disable, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Get the current state of the local UWB_location adapter.
     * <p>Possible return values are
     * {@link #ENABLE_STATE_OFF},
     * {@link #ENABLE_STATE_TURNING_ON},
     * {@link #ENABLE_STATE_ON},
     * {@link #ENABLE_STATE_TURNING_OFF}.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return current state of the local UWB adapter
     */
@Override public int getEnableState() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getEnableState, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Turn on Radio.This turns on the Local UWB Radio.
     * Can be used as generic API for any other radio turn on also (cf AirPlane mode).
     * <p>This is an asynchronous call: it will return immediately, and
     * clients should listen for {@link #onUWBRadioStateChange()}
     * to be notified of subsequent UWB Radio state changes. If this call returns
     * true, then the Radio state will immediately transition from {@link
     * #STATE_OFF} to {@link #STATE_TURNING_ON}, and some time
     * later transition to either {@link #STATE_OFF} or {@link
     * #STATE_ON}. If this call returns false then there was an
     * immediate problem that will prevent the UWB radio from being turned on -
     * such as Airplane mode, or the UWB Radio is already turned on.
     * <p>Requires the {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * permission
     *
     * @return true to indicate UWB radio enabling has begun, or false on
     *         immediate error
     */
@Override public boolean enableRadio() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_enableRadio, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Turn Off Radio.This turns Off the Local UWB Radio.
     * Can be used as generic API for any other radio turn Off also (cf AirPlane mode).
     * <p>This is an asynchronous call: it will return immediately, and
     * clients should listen for {@link #onUWBRadioStateChange()}
     * to be notified of subsequent UWB Radio state changes. If this call returns
     * true, then the Radio state will immediately transition from {@link
     * #STATE_ON} to {@link #STATE_TURNING_OFF}, and some time
     * later transition to either {@link #STATE_ON} or {@link
     * #STATE_OFF}. If this call returns false then there was an
     * immediate problem that will prevent the UWB radio from being turned off -
     * such as the UWB Radio is already turned off.
     * <p>Requires the {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * permission
     *
     * @return true to indicate UWB radio disabling has begun, or false on
     *         immediate error
     */
@Override public boolean disableRadio() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_disableRadio, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Get the current state of the local UWB_location adapter.
     * <p>Possible return values are
     * {@link #RADIO_STATE_OFF},
     * {@link #RADIO_STATE_TURNING_ON},
     * {@link #RADIO_STATE_ON},
     * {@link #RADIO_STATE_TURNING_OFF}.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return current state of the local UWB adapter
     */
@Override public int getRadioState() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getRadioState, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//*********************************************************************************
//***************************  Discovery control **********************************
//*********************************************************************************
/**
     * Get the current UWB scan mode of the local UWB adapter.
     * <p>The UWB scan mode determines if the local adapter is
     * discoverable from remote UWB devices.
     * <p>Possible values are:
     * {@link #SCAN_MODE_NONE},
     * {@link #SCAN_MODE_DISCOVERABLE},
     * {@link #SCAN_MODE_DISCOVERABLE_SECURE}.
     * <p>If UWB state is not {@link #STATE_ON}, this API
     * will return {@link #SCAN_MODE_NONE}. After turning on UWB,
     * wait for {@link #onUWBStateChange()} with {@link #STATE_ON}
     * to get the updated value.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return scan mode
     */
@Override public int getScanMode() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getScanMode, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Set the UWB scan mode of the local UWB adapter.
     * <p>The UWB scan mode determines if the local adapter is
     * discoverable from remote UWB devices.
     * <p>For privacy reasons, discoverable mode is automatically turned off
     * after <code>duration</code> seconds. For example, 30 seconds should be
     * enough for a remote device to initiate and complete its discovery
     * process.
     * <p>Valid scan mode values are:
     * {@link #SCAN_MODE_NONE},
     * {@link #SCAN_MODE_DISCOVERABLE},
     * {@link #SCAN_MODE_DISCOVERABLE_SECURE}.
     * <p>If UWB state is not {@link #STATE_ON}, this API
     * will return false. After turning on UWB,
     * wait for {@link #ACTION_STATE_CHANGED} with {@link #STATE_ON}
     * to get the updated value.
     *
     * @param mode valid scan mode
     * @param duration time in seconds to apply scan mode, only used for
     *                 {@link #SCAN_MODE_DISCOVERABLE}
					   {@link #SCAN_MODE_DISCOVERABLE_SECURE}
     * @return     true if the scan mode was set, false otherwise
	 *
     * @hide
     */
@Override public boolean setScanMode(int mode, int duration) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(mode);
_data.writeInt(duration);
mRemote.transact(Stub.TRANSACTION_setScanMode, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Start a bonding (pairing) process with a remote Master.
	 * The master device is identified by its short adress (24bits)
	 * The bonding process can be standard or secure
	 * The local adapter can only be bonded with one master
     * <p>This is an asynchronous call, it will return immediately.
     * Listen to {@link #onBondingStateChange()} to be notified when
     * the bonding process completes, and its result.
	 *
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
     *
   	 * @param mode valid bonding mode (BONDING_STANDARD,BONDING_SECURE etc..)
     * @param masterShortAdress - The remote Master to start bonding with
	 *
     * @return false on immediate error (ex already bonded), true if bonding will begin
	 *
     * @hide
     */
@Override public boolean startBonding(int mode, int masterShortAdress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(mode);
_data.writeInt(masterShortAdress);
mRemote.transact(Stub.TRANSACTION_startBonding, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Start the bonding (pairing) process with a remote master using some
     * Out Of Band data (got from trust channel such as GSM,secure IP).
     *
     * <p>This is an asynchronous call, it will return immediately.
     * Listen to {@link #onBondingStateChange()} to be notified when
     * the bonding process completes, and its result.
     *
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
     *
     * @param masterShortAdress - The remote device to start bonding with
   	 * @param bondingMode valid bondig mode (BONDING_STANDARD,BONDING_SECURE etc..)
	 * @param data : some data acquired from other channels ( ex : binary sms)
     *
     * @hide
     */
@Override public boolean startBondingOutOfBand(int bondingMode, int masterShortAdress, byte[] data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(bondingMode);
_data.writeInt(masterShortAdress);
_data.writeByteArray(data);
mRemote.transact(Stub.TRANSACTION_startBondingOutOfBand, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Accept the current bonding process initiate by the IUwbDevice
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
	 *
	 * @see Callback : onDeviceBondingRequest()
	 * @param device the IUwbDevice candidate for bonding
	 *
     * @hide
     */
@Override public void acceptBondingRequest(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_acceptBondingRequest, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * Decline the current bonding process initiate by the IUwbDevice
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
	 *
	 * @see Callback : onDeviceBondingRequest()
	 * @param device the IUwbDevice candidate for bonding
	 *
     * @hide
     */
@Override public void declineBondingRequest(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_declineBondingRequest, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * Cancel an in-progress bonding process.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
	 *
	 * @param device the IUwbDevice candidate for bonding
     * @return true on success, false on error
     * @hide
     */
@Override public boolean cancelBondingProcess(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_cancelBondingProcess, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Remove bond (pairing) with the remote device.
     * <p>Delete the link key associated with the remote device, and
     * immediately terminate connections to that device that require
     * authentication and encryption.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
	 *
	 * @param device the bonded IUwbDevice
     * @return true on success, false on error
	 *
     * @hide
     */
@Override public boolean removeBond(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_removeBond, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Accept the current attach process initiated by the IUwbDevice
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
	 *
	 * @see Callback : onAttachRequest()
	 * @param device the IUwbDevice candidate for attachment
	 *
     * @hide
     */
@Override public void acceptAttachRequest(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_acceptAttachRequest, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * Decline the current attach process initiated by the IUwbDevice
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
	 *
	 * @see Callback : onAttachRequest()
	 * @param device the IUwbDevice candidate for attachment
	 *
     * @hide
     */
@Override public void declineAttachRequest(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_declineAttachRequest, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * Return the set of devices that are bonded
     * (paired) to the local adapter.
     * Objects can be :
     * -> several tags paired with the local dapter
     * -> One (and only one) other master if the local adapter is paired with another master
     * <p>If UWB state is not {@link #STATE_ON}, this API
     * will return an empty set. After turning on UWB,
     * wait for {@link #onUWBStateChange()} with {@link #STATE_ON}
     * to get the updated value.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}.
     *
     * @return list of devices mac addresss, or null if error
     */
@Override public int[] getBondedDevices() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int[] _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getBondedDevices, _data, _reply, 0);
_reply.readException();
_result = _reply.createIntArray();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Return the set of device that are bonded
     * (paired) to the local adapter and attached (active).
     * <p>If UWB state is not {@link #STATE_ON}, this API
     * will return an empty set. After turning on UWB,
     * wait for {@link #onUWBStateChange()} with {@link #STATE_ON}
     * to get the updated value.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}.
     *
     * @return list of devices mac addresss, or null if error
     */
@Override public int[] getAttachedDevices() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int[] _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getAttachedDevices, _data, _reply, 0);
_reply.readException();
_result = _reply.createIntArray();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Retrieve a device by its mac address
     * @return null if no device found
     */
@Override public com.bespoon.uwb.IUwbDevice getDevice(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
com.bespoon.uwb.IUwbDevice _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_getDevice, _data, _reply, 0);
_reply.readException();
_result = com.bespoon.uwb.IUwbDevice.Stub.asInterface(_reply.readStrongBinder());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Access to the local device provided by this adapter.
     */
@Override public com.bespoon.uwb.IUwbDevice getLocalDevice() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
com.bespoon.uwb.IUwbDevice _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getLocalDevice, _data, _reply, 0);
_reply.readException();
_result = com.bespoon.uwb.IUwbDevice.Stub.asInterface(_reply.readStrongBinder());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
// TODO remove this once the bonding process is fully implemented

@Override public void addManualBond(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_addManualBond, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_registerListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_unregisterListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_enable = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_disable = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_getEnableState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_enableRadio = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_disableRadio = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_getRadioState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_getScanMode = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_setScanMode = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_startBonding = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_startBondingOutOfBand = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_acceptBondingRequest = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
static final int TRANSACTION_declineBondingRequest = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
static final int TRANSACTION_cancelBondingProcess = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
static final int TRANSACTION_removeBond = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
static final int TRANSACTION_acceptAttachRequest = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
static final int TRANSACTION_declineAttachRequest = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
static final int TRANSACTION_getBondedDevices = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
static final int TRANSACTION_getAttachedDevices = (android.os.IBinder.FIRST_CALL_TRANSACTION + 19);
static final int TRANSACTION_getDevice = (android.os.IBinder.FIRST_CALL_TRANSACTION + 20);
static final int TRANSACTION_getLocalDevice = (android.os.IBinder.FIRST_CALL_TRANSACTION + 21);
static final int TRANSACTION_addManualBond = (android.os.IBinder.FIRST_CALL_TRANSACTION + 22);
}
public void registerListener(com.bespoon.uwb.IUwbServiceListener listener) throws android.os.RemoteException;
public void unregisterListener(com.bespoon.uwb.IUwbServiceListener listener) throws android.os.RemoteException;
//*********************************************************************************
//***************************   Session control  **********************************
//*********************************************************************************
/**
     * Turn on the local UWB adapter&mdash;do not use without explicit
     * user action to turn on UWB Location.
     * <p>This powers on the underlying UWB hardware, starts UWB radio and starts all
     * UWB Location system services.
     * <p class="caution"><strong>UWB should never be enabled without
     * direct user consent</strong>. If you want to turn on UWB in order
     * to create a wireless network, you should use the {@link
     * #ACTION_REQUEST_ENABLE} Intent, which will raise a dialog that requests
     * user permission to turn on UWB Location. The {@link #enable()} method is
     * provided only for applications that include a user interface for changing
     * system settings, such as a "power manager" app.</p>
     * <p>This is an asynchronous call: it will return immediately, and
     * clients should listen for {@link #onUWBStateChange()}
     * to be notified of subsequent adapter state changes. If this call returns
     * true, then the adapter state will immediately transition from {@link
     * #STATE_OFF} to {@link #STATE_TURNING_ON}, and some time
     * later transition to either {@link #STATE_OFF} or {@link
     * #STATE_ON}. If this call returns false then there was an
     * immediate problem that will prevent the adapter from being turned on -
     * such as Airplane mode, or the adapter is already turned on.
     * <p>Requires the {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * permission
     *
     * @return true to indicate adapter startup has begun, or false on
     *         immediate error
     */
public boolean enable() throws android.os.RemoteException;
/**
     * Turn off the local UWB adapter&mdash;do not use without explicit
     * user action to turn off UWB.
     * <p>This gracefully shuts down UWB radio, all UWB connections, stops UWB
     * system services, and powers down the underlying UWB hardware.
     * <p class="caution"><strong>UWB should never be disabled without
     * direct user consent</strong>. The {@link #disable()} method is
     * provided only for applications that include a user interface for changing
     * system settings, such as a "power manager" app.</p>
     * <p>This is an asynchronous call: it will return immediately, and
     * clients should listen for {@link #onUWBStateChange()}
     * to be notified of subsequent adapter state changes. If this call returns
     * true, then the adapter state will immediately transition from {@link
     * #STATE_ON} to {@link #STATE_TURNING_OFF}, and some time
     * later transition to either {@link #STATE_OFF} or {@link
     * #STATE_ON}. If this call returns false then there was an
     * immediate problem that will prevent the adapter from being turned off -
     * such as the adapter already being turned off.
     * <p>Requires the {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * permission
     *
     * @return true to indicate adapter shutdown has begun, or false on
     *         immediate error
     */
public boolean disable() throws android.os.RemoteException;
/**
     * Get the current state of the local UWB_location adapter.
     * <p>Possible return values are
     * {@link #ENABLE_STATE_OFF},
     * {@link #ENABLE_STATE_TURNING_ON},
     * {@link #ENABLE_STATE_ON},
     * {@link #ENABLE_STATE_TURNING_OFF}.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return current state of the local UWB adapter
     */
public int getEnableState() throws android.os.RemoteException;
/**
     * Turn on Radio.This turns on the Local UWB Radio.
     * Can be used as generic API for any other radio turn on also (cf AirPlane mode).
     * <p>This is an asynchronous call: it will return immediately, and
     * clients should listen for {@link #onUWBRadioStateChange()}
     * to be notified of subsequent UWB Radio state changes. If this call returns
     * true, then the Radio state will immediately transition from {@link
     * #STATE_OFF} to {@link #STATE_TURNING_ON}, and some time
     * later transition to either {@link #STATE_OFF} or {@link
     * #STATE_ON}. If this call returns false then there was an
     * immediate problem that will prevent the UWB radio from being turned on -
     * such as Airplane mode, or the UWB Radio is already turned on.
     * <p>Requires the {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * permission
     *
     * @return true to indicate UWB radio enabling has begun, or false on
     *         immediate error
     */
public boolean enableRadio() throws android.os.RemoteException;
/**
     * Turn Off Radio.This turns Off the Local UWB Radio.
     * Can be used as generic API for any other radio turn Off also (cf AirPlane mode).
     * <p>This is an asynchronous call: it will return immediately, and
     * clients should listen for {@link #onUWBRadioStateChange()}
     * to be notified of subsequent UWB Radio state changes. If this call returns
     * true, then the Radio state will immediately transition from {@link
     * #STATE_ON} to {@link #STATE_TURNING_OFF}, and some time
     * later transition to either {@link #STATE_ON} or {@link
     * #STATE_OFF}. If this call returns false then there was an
     * immediate problem that will prevent the UWB radio from being turned off -
     * such as the UWB Radio is already turned off.
     * <p>Requires the {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * permission
     *
     * @return true to indicate UWB radio disabling has begun, or false on
     *         immediate error
     */
public boolean disableRadio() throws android.os.RemoteException;
/**
     * Get the current state of the local UWB_location adapter.
     * <p>Possible return values are
     * {@link #RADIO_STATE_OFF},
     * {@link #RADIO_STATE_TURNING_ON},
     * {@link #RADIO_STATE_ON},
     * {@link #RADIO_STATE_TURNING_OFF}.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return current state of the local UWB adapter
     */
public int getRadioState() throws android.os.RemoteException;
//*********************************************************************************
//***************************  Discovery control **********************************
//*********************************************************************************
/**
     * Get the current UWB scan mode of the local UWB adapter.
     * <p>The UWB scan mode determines if the local adapter is
     * discoverable from remote UWB devices.
     * <p>Possible values are:
     * {@link #SCAN_MODE_NONE},
     * {@link #SCAN_MODE_DISCOVERABLE},
     * {@link #SCAN_MODE_DISCOVERABLE_SECURE}.
     * <p>If UWB state is not {@link #STATE_ON}, this API
     * will return {@link #SCAN_MODE_NONE}. After turning on UWB,
     * wait for {@link #onUWBStateChange()} with {@link #STATE_ON}
     * to get the updated value.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return scan mode
     */
public int getScanMode() throws android.os.RemoteException;
/**
     * Set the UWB scan mode of the local UWB adapter.
     * <p>The UWB scan mode determines if the local adapter is
     * discoverable from remote UWB devices.
     * <p>For privacy reasons, discoverable mode is automatically turned off
     * after <code>duration</code> seconds. For example, 30 seconds should be
     * enough for a remote device to initiate and complete its discovery
     * process.
     * <p>Valid scan mode values are:
     * {@link #SCAN_MODE_NONE},
     * {@link #SCAN_MODE_DISCOVERABLE},
     * {@link #SCAN_MODE_DISCOVERABLE_SECURE}.
     * <p>If UWB state is not {@link #STATE_ON}, this API
     * will return false. After turning on UWB,
     * wait for {@link #ACTION_STATE_CHANGED} with {@link #STATE_ON}
     * to get the updated value.
     *
     * @param mode valid scan mode
     * @param duration time in seconds to apply scan mode, only used for
     *                 {@link #SCAN_MODE_DISCOVERABLE}
					   {@link #SCAN_MODE_DISCOVERABLE_SECURE}
     * @return     true if the scan mode was set, false otherwise
	 *
     * @hide
     */
public boolean setScanMode(int mode, int duration) throws android.os.RemoteException;
/**
     * Start a bonding (pairing) process with a remote Master.
	 * The master device is identified by its short adress (24bits)
	 * The bonding process can be standard or secure
	 * The local adapter can only be bonded with one master
     * <p>This is an asynchronous call, it will return immediately.
     * Listen to {@link #onBondingStateChange()} to be notified when
     * the bonding process completes, and its result.
	 *
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
     *
   	 * @param mode valid bonding mode (BONDING_STANDARD,BONDING_SECURE etc..)
     * @param masterShortAdress - The remote Master to start bonding with
	 *
     * @return false on immediate error (ex already bonded), true if bonding will begin
	 *
     * @hide
     */
public boolean startBonding(int mode, int masterShortAdress) throws android.os.RemoteException;
/**
     * Start the bonding (pairing) process with a remote master using some
     * Out Of Band data (got from trust channel such as GSM,secure IP).
     *
     * <p>This is an asynchronous call, it will return immediately.
     * Listen to {@link #onBondingStateChange()} to be notified when
     * the bonding process completes, and its result.
     *
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
     *
     * @param masterShortAdress - The remote device to start bonding with
   	 * @param bondingMode valid bondig mode (BONDING_STANDARD,BONDING_SECURE etc..)
	 * @param data : some data acquired from other channels ( ex : binary sms)
     *
     * @hide
     */
public boolean startBondingOutOfBand(int bondingMode, int masterShortAdress, byte[] data) throws android.os.RemoteException;
/**
     * Accept the current bonding process initiate by the IUwbDevice
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
	 *
	 * @see Callback : onDeviceBondingRequest()
	 * @param device the IUwbDevice candidate for bonding
	 *
     * @hide
     */
public void acceptBondingRequest(int shortAddress) throws android.os.RemoteException;
/**
     * Decline the current bonding process initiate by the IUwbDevice
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
	 *
	 * @see Callback : onDeviceBondingRequest()
	 * @param device the IUwbDevice candidate for bonding
	 *
     * @hide
     */
public void declineBondingRequest(int shortAddress) throws android.os.RemoteException;
/**
     * Cancel an in-progress bonding process.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
	 *
	 * @param device the IUwbDevice candidate for bonding
     * @return true on success, false on error
     * @hide
     */
public boolean cancelBondingProcess(int shortAddress) throws android.os.RemoteException;
/**
     * Remove bond (pairing) with the remote device.
     * <p>Delete the link key associated with the remote device, and
     * immediately terminate connections to that device that require
     * authentication and encryption.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
	 *
	 * @param device the bonded IUwbDevice
     * @return true on success, false on error
	 *
     * @hide
     */
public boolean removeBond(int shortAddress) throws android.os.RemoteException;
/**
     * Accept the current attach process initiated by the IUwbDevice
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
	 *
	 * @see Callback : onAttachRequest()
	 * @param device the IUwbDevice candidate for attachment
	 *
     * @hide
     */
public void acceptAttachRequest(int shortAddress) throws android.os.RemoteException;
/**
     * Decline the current attach process initiated by the IUwbDevice
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}.
	 *
	 * @see Callback : onAttachRequest()
	 * @param device the IUwbDevice candidate for attachment
	 *
     * @hide
     */
public void declineAttachRequest(int shortAddress) throws android.os.RemoteException;
/**
     * Return the set of devices that are bonded
     * (paired) to the local adapter.
     * Objects can be :
     * -> several tags paired with the local dapter
     * -> One (and only one) other master if the local adapter is paired with another master
     * <p>If UWB state is not {@link #STATE_ON}, this API
     * will return an empty set. After turning on UWB,
     * wait for {@link #onUWBStateChange()} with {@link #STATE_ON}
     * to get the updated value.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}.
     *
     * @return list of devices mac addresss, or null if error
     */
public int[] getBondedDevices() throws android.os.RemoteException;
/**
     * Return the set of device that are bonded
     * (paired) to the local adapter and attached (active).
     * <p>If UWB state is not {@link #STATE_ON}, this API
     * will return an empty set. After turning on UWB,
     * wait for {@link #onUWBStateChange()} with {@link #STATE_ON}
     * to get the updated value.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}.
     *
     * @return list of devices mac addresss, or null if error
     */
public int[] getAttachedDevices() throws android.os.RemoteException;
/**
     * Retrieve a device by its mac address
     * @return null if no device found
     */
public com.bespoon.uwb.IUwbDevice getDevice(int shortAddress) throws android.os.RemoteException;
/**
     * Access to the local device provided by this adapter.
     */
public com.bespoon.uwb.IUwbDevice getLocalDevice() throws android.os.RemoteException;
// TODO remove this once the bonding process is fully implemented

public void addManualBond(int shortAddress) throws android.os.RemoteException;
}
