package com.example.dds_test;

import android.app.Fragment;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class FieldFragment extends Fragment {

    private int background;
    private Drawable backgroundDrawable;

    public FieldFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.background = this.getArguments().getInt("background");

        switch (this.background){
            case 1 :
                this.backgroundDrawable = this.getResources().getDrawable(R.drawable.field_basket);
                break;
            case 2 :
                this.backgroundDrawable = this.getResources().getDrawable(R.drawable.field_futsal);
                break;
            case 3 :
                this.backgroundDrawable = this.getResources().getDrawable(R.drawable.field_hockey);
                break;
            case 4 :
                this.backgroundDrawable = this.getResources().getDrawable(R.drawable.field_tennis);
                break;
            case 5 :
                this.backgroundDrawable = this.getResources().getDrawable(R.drawable.field_badminton);
                break;
            case 6 :
                this.backgroundDrawable = this.getResources().getDrawable(R.drawable.field_handball);
                break;

            case 7 : this.backgroundDrawable = null; break;
            case 8 : this.backgroundDrawable = null; break;

            default : this.backgroundDrawable = null; break;
        }
        if(this.backgroundDrawable != null) {
            container.setBackground(this.backgroundDrawable);
        }


        View v = inflater.inflate(R.layout.fragment_field, container, false);
        View id = v.findViewById(R.id.affichageId);
        Log.d("Testing getting View",""+id);


        return v;
    }


}
