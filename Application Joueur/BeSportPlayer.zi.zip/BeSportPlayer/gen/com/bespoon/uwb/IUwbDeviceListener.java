/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\Users\\rcour\\workspace\\Base_UWB\\BeSportPlayer\\src\\com\\bespoon\\uwb\\IUwbDeviceListener.aidl
 */
package com.bespoon.uwb;
public interface IUwbDeviceListener extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.bespoon.uwb.IUwbDeviceListener
{
private static final java.lang.String DESCRIPTOR = "com.bespoon.uwb.IUwbDeviceListener";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.bespoon.uwb.IUwbDeviceListener interface,
 * generating a proxy if needed.
 */
public static com.bespoon.uwb.IUwbDeviceListener asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.bespoon.uwb.IUwbDeviceListener))) {
return ((com.bespoon.uwb.IUwbDeviceListener)iin);
}
return new com.bespoon.uwb.IUwbDeviceListener.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_onBatteryStateChanged:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
boolean _arg1;
_arg1 = (0!=data.readInt());
this.onBatteryStateChanged(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_onMotionStateChanged:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
boolean _arg1;
_arg1 = (0!=data.readInt());
this.onMotionStateChanged(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_onLocationProfileChanged:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
int _arg2;
_arg2 = data.readInt();
int _arg3;
_arg3 = data.readInt();
this.onLocationProfileChanged(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
return true;
}
case TRANSACTION_onLocationRateChanged:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
int _arg2;
_arg2 = data.readInt();
int _arg3;
_arg3 = data.readInt();
this.onLocationRateChanged(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
return true;
}
case TRANSACTION_onDistanceChanged:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
long _arg2;
_arg2 = data.readLong();
float _arg3;
_arg3 = data.readFloat();
this.onDistanceChanged(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
return true;
}
case TRANSACTION_onLocationChanged:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
long _arg2;
_arg2 = data.readLong();
float _arg3;
_arg3 = data.readFloat();
float _arg4;
_arg4 = data.readFloat();
float _arg5;
_arg5 = data.readFloat();
this.onLocationChanged(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5);
reply.writeNoException();
return true;
}
case TRANSACTION_onLost:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onLost(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onRecovered:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onRecovered(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onDataSent:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
this.onDataSent(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_onDataReceived:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
byte[] _arg1;
_arg1 = data.createByteArray();
this.onDataReceived(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_onSensorDataReceived:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
int _arg2;
_arg2 = data.readInt();
long _arg3;
_arg3 = data.readLong();
float[] _arg4;
_arg4 = data.createFloatArray();
this.onSensorDataReceived(_arg0, _arg1, _arg2, _arg3, _arg4);
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.bespoon.uwb.IUwbDeviceListener
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/**********************  Device Info callbacks 	*//**
	 * Called when the device changes Battery level.
	 * @param prevLevel : previous battery level
	 * @param newLevel : new battery level
	 *//*void onBatteryLevelChanged(int shortAddress, int prevLevel, int newLevel);*//**
	 * Called when the device enter or leave low battery state.
	 * @param isLowBat : is the device low battery?
	 */
@Override public void onBatteryStateChanged(int shortAddress, boolean isLow) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
_data.writeInt(((isLow)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_onBatteryStateChanged, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called when the device changes motion state  .
	 * @param isMoving
	 */
@Override public void onMotionStateChanged(int shortAddress, boolean isMoving) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
_data.writeInt(((isMoving)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_onMotionStateChanged, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**********************  	Ranging callbacks 	*//**
	 * Called whenever we tried to change a device Profile.
	 * @param prevState : previous profile
	 * @param newState : new profile
	 * @param status : status of the profile change
	 */
@Override public void onLocationProfileChanged(int shortAddress, int prevProfile, int newProfile, int status) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
_data.writeInt(prevProfile);
_data.writeInt(newProfile);
_data.writeInt(status);
mRemote.transact(Stub.TRANSACTION_onLocationProfileChanged, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called whenever we tried to change a device loc Rate 
	 * or whenever an agile tag changed its locrate.
	 * @param prevState : previous LocRate
	 * @param newState : new LocRate
	 * @param status : status of the LocRate change
	 */
@Override public void onLocationRateChanged(int shortAddress, int prevLocRate, int newLocRate, int status) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
_data.writeInt(prevLocRate);
_data.writeInt(newLocRate);
_data.writeInt(status);
mRemote.transact(Stub.TRANSACTION_onLocationRateChanged, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called whenever a device distance changes.
	 * @param out accuracy : the distance last value accuracy
	 * @param out timestamp : the distance last value timestamp in nanosecond
	 * @param distance last known device distance to this local adapter
	 */
@Override public void onDistanceChanged(int shortAddress, int accuracy, long timestamp, float distance) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
_data.writeInt(accuracy);
_data.writeLong(timestamp);
_data.writeFloat(distance);
mRemote.transact(Stub.TRANSACTION_onDistanceChanged, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called whenever a device location changes.
	 * @param out accuracy : the location last value accuracy
	 * @param out timestamp : the location last value timestamp in nanosecond
	 * @param out x,y,z : the location last coordinates
	 */
@Override public void onLocationChanged(int shortAddress, int accuracy, long timestamp, float x, float y, float z) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
_data.writeInt(accuracy);
_data.writeLong(timestamp);
_data.writeFloat(x);
_data.writeFloat(y);
_data.writeFloat(z);
mRemote.transact(Stub.TRANSACTION_onLocationChanged, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called when a previously known device becomes unreachable.
	 * @see #onRecovered()
	 */
@Override public void onLost(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_onLost, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called when a previously unreachable device becomes reachable again.
	 * @see #onLost()
	 */
@Override public void onRecovered(int shortAddress) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
mRemote.transact(Stub.TRANSACTION_onRecovered, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**********************  	Data callbacks 	*//**
	 * Called whenever we tried to send data to the device 
	 * @param status : status of the data transfert
	 */
@Override public void onDataSent(int shortAddress, int status) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
_data.writeInt(status);
mRemote.transact(Stub.TRANSACTION_onDataSent, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
	 * Called whenever the device sent us some user data .
	 * @param data : byte stream from device
	 */
@Override public void onDataReceived(int shortAddress, byte[] data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
_data.writeByteArray(data);
mRemote.transact(Stub.TRANSACTION_onDataReceived, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**********************  	Sensor callbacks 	*//**
	 * Called whenever the device sent us some sensor data.
	 * @param sensor : the refreshed data sensor
	 * @param out activeSensor : the sensor with new data
	 * @param out accuracy : the sensor last value accuracy
	 * @param out timestamp : the sensor last value timestamp in nanosecond
	 * @param out data : The length and contents of the value array depends on which sensor type is being monitored
	 */
@Override public void onSensorDataReceived(int shortAddress, int activeSensor, int accuracy, long timestamp, float[] data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(shortAddress);
_data.writeInt(activeSensor);
_data.writeInt(accuracy);
_data.writeLong(timestamp);
_data.writeFloatArray(data);
mRemote.transact(Stub.TRANSACTION_onSensorDataReceived, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_onBatteryStateChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_onMotionStateChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_onLocationProfileChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_onLocationRateChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_onDistanceChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_onLocationChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_onLost = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_onRecovered = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_onDataSent = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_onDataReceived = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_onSensorDataReceived = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
}
/**********************  Device Info callbacks 	*//**
	 * Called when the device changes Battery level.
	 * @param prevLevel : previous battery level
	 * @param newLevel : new battery level
	 *//*void onBatteryLevelChanged(int shortAddress, int prevLevel, int newLevel);*//**
	 * Called when the device enter or leave low battery state.
	 * @param isLowBat : is the device low battery?
	 */
public void onBatteryStateChanged(int shortAddress, boolean isLow) throws android.os.RemoteException;
/**
	 * Called when the device changes motion state  .
	 * @param isMoving
	 */
public void onMotionStateChanged(int shortAddress, boolean isMoving) throws android.os.RemoteException;
/**********************  	Ranging callbacks 	*//**
	 * Called whenever we tried to change a device Profile.
	 * @param prevState : previous profile
	 * @param newState : new profile
	 * @param status : status of the profile change
	 */
public void onLocationProfileChanged(int shortAddress, int prevProfile, int newProfile, int status) throws android.os.RemoteException;
/**
	 * Called whenever we tried to change a device loc Rate 
	 * or whenever an agile tag changed its locrate.
	 * @param prevState : previous LocRate
	 * @param newState : new LocRate
	 * @param status : status of the LocRate change
	 */
public void onLocationRateChanged(int shortAddress, int prevLocRate, int newLocRate, int status) throws android.os.RemoteException;
/**
	 * Called whenever a device distance changes.
	 * @param out accuracy : the distance last value accuracy
	 * @param out timestamp : the distance last value timestamp in nanosecond
	 * @param distance last known device distance to this local adapter
	 */
public void onDistanceChanged(int shortAddress, int accuracy, long timestamp, float distance) throws android.os.RemoteException;
/**
	 * Called whenever a device location changes.
	 * @param out accuracy : the location last value accuracy
	 * @param out timestamp : the location last value timestamp in nanosecond
	 * @param out x,y,z : the location last coordinates
	 */
public void onLocationChanged(int shortAddress, int accuracy, long timestamp, float x, float y, float z) throws android.os.RemoteException;
/**
	 * Called when a previously known device becomes unreachable.
	 * @see #onRecovered()
	 */
public void onLost(int shortAddress) throws android.os.RemoteException;
/**
	 * Called when a previously unreachable device becomes reachable again.
	 * @see #onLost()
	 */
public void onRecovered(int shortAddress) throws android.os.RemoteException;
/**********************  	Data callbacks 	*//**
	 * Called whenever we tried to send data to the device 
	 * @param status : status of the data transfert
	 */
public void onDataSent(int shortAddress, int status) throws android.os.RemoteException;
/**
	 * Called whenever the device sent us some user data .
	 * @param data : byte stream from device
	 */
public void onDataReceived(int shortAddress, byte[] data) throws android.os.RemoteException;
/**********************  	Sensor callbacks 	*//**
	 * Called whenever the device sent us some sensor data.
	 * @param sensor : the refreshed data sensor
	 * @param out activeSensor : the sensor with new data
	 * @param out accuracy : the sensor last value accuracy
	 * @param out timestamp : the sensor last value timestamp in nanosecond
	 * @param out data : The length and contents of the value array depends on which sensor type is being monitored
	 */
public void onSensorDataReceived(int shortAddress, int activeSensor, int accuracy, long timestamp, float[] data) throws android.os.RemoteException;
}
