package com.raphael.besport;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import edu.esiee.localisation.R;

public class StartActivity extends Activity {

    //private String TAG = "StartActivty";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
    }

    public void onChoiceClick(View pV){
        Intent vI = new Intent(this, MainActivity.class);
        
        //R�cup�re les infos des �ditText
        EditText vNametext = (EditText)findViewById(R.id.editText1);
        EditText vNumberText = (EditText)findViewById(R.id.editText2);
        
        EditText vLargeurText = (EditText)findViewById(R.id.editText3);
        EditText vLongueurText = (EditText)findViewById(R.id.editText4);

    	String vName = vNametext.getText().toString();
    	String vNumber = vNumberText.getText().toString();
    	
    	Double longueur;
    	Double largeur;
    	try{
	    	longueur = Double.parseDouble(vLongueurText.getText().toString());
	    	largeur = Double.parseDouble(vLargeurText.getText().toString());
    	}
    	catch(Exception e){
    		Toast.makeText(this, "Vous devez entrer les mesures du terrain", Toast.LENGTH_LONG).show();
    		return;
    	}
    	
    	RadioGroup radioGroup = (RadioGroup)findViewById(R.id.radioGroup1);
    	
    	//Check L'�quipe du joueur
    	int selectId = radioGroup.getCheckedRadioButtonId();
    	RadioButton radioButton = (RadioButton)findViewById(selectId);
    	String TeamName = radioButton.getText().toString();
    	int team = 0;
    	if(TeamName =="Home"){
    		team = 1;
    	}
    	else{
    		team = 2;
    	}
    	
    	//Passe les arguments si ils sont valides
    	if((vName !=null && vNumber!=null && longueur != null &&largeur != null) && (!vName.equals("") && !vNumber.equals("") && !longueur.equals("") && !largeur.equals("") )){
    		if(vName != null && vNumber != null){
            	vI.putExtra("name", vName);
            	vI.putExtra("number", vNumber);
            	vI.putExtra("largeur", largeur);
            	vI.putExtra("longueur", longueur);
            	vI.putExtra("team", team);
            }
            startActivity(vI);
    	}
    	else{
    		Toast.makeText(this, "Vous devez remplir tous les champs", Toast.LENGTH_LONG).show();
    	}

    	
        
    }
}
