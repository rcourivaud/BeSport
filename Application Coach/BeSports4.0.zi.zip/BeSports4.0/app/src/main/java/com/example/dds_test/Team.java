package com.example.dds_test;

import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

/**
 * Created by Raphael on 19/12/2015.
 */
public class Team {

    String TAG = "Team.Class";


    private String aName;
    private List<Player> aPlayerList;
    private int teamColor;
    private List<String> aPlayerNameList = new ArrayList<>();

    public Team(String pName){
        this.aName = pName;
        this.aPlayerList = new ArrayList<>();
    }

    public List<Player> getaPlayerList() {
        return aPlayerList;
    }

    public int getTeamColor() {
        return teamColor;
    }

    public void setTeamColor(int color) {
        this.teamColor = color;
    }
    public void addPlayer(Player pPlayer){
        this.aPlayerList.add(pPlayer);
    }


    public void addPlayer(String pPlayerName, int pPlayerNumero){
        this.aPlayerList.add(new Player(pPlayerName, pPlayerNumero));
    }

    public void addPlayer(int pPlayerNumero){
        Random rand = new Random();
        this.aPlayerList.add(new Player(pPlayerNumero));
        this.aPlayerList.get(pPlayerNumero).setPosition(rand.nextInt(80)+10, rand.nextInt(80)+10);
    }

    public ArrayList<HashMap<String, String>> getListForDisplay(){
        ArrayList<HashMap<String, String>> listItem = new ArrayList<HashMap<String, String>>();
        for(Player pP: this.aPlayerList){
            listItem.add(pP.getMapForDisplay());
        }
        return listItem;
    }

    public void updateAllPlayers(){
        for(Player pP: this.aPlayerList){
            Log.d(TAG, pP.toString());
        }
    }

    @Override
    public String toString(){
        String vReturnString = this.aName + "\n";
        for(Player pP:this.aPlayerList){
            vReturnString += pP.toString();
        }
        return vReturnString;
    }

    public void createTestTeam(){
        for(int i=0; i<3; i++){
            this.addPlayer(i);
        }
    }

    public void updateNameList(){
        for (Player player : this.aPlayerList) {
            if(!this.aPlayerNameList.contains(player.getaName())) {
                this.aPlayerNameList.add(player.getaName());
            }
        }
    }


    public List<String> getaPlayerNameList() {
        return aPlayerNameList;
    }

    public Player getPlayerFromTeam(String pNom){
        Player player;
        int position = this.aPlayerNameList.indexOf(pNom);
        player = this.aPlayerList.get(position);
        return player;
    }
}
