package com.bespoon.uwb;

public final class Uwb {
    public static final int ENABLE_STATE_OFF = 0;
    public static final int ENABLE_STATE_TURNING_OFF = 1;
    public static final int ENABLE_STATE_ON = 2;
    public static final int ENABLE_STATE_TURNING_ON = 3;

    public static final int RADIO_STATE_OFF = 0;
    public static final int RADIO_STATE_TURNING_OFF = 1;
    public static final int RADIO_STATE_ON = 2;
    public static final int RADIO_STATE_TURNING_ON = 3;

    /**
     * The Device bonding capabilities : normal,secure, assisted
     * Note : keep maskable as a device may have several capabilities
     */
    public static final int BONDING_STANDARD  	= 0x00001;
    public static final int BONDING_SECURE		= 0x00002;
    public static final int BONDING_ASSISTED	= 0x00004;

    public static final int BOND_NONE = 0;
    public static final int BOND_BONDING = 1;
    public static final int BOND_BONDED = 2;

    /**
     * The Device profiles supported : Tag,Base,relay,sniffer etc ..
     * Note : keep maskable as a device may support more than one at the same time
     * ex : TYPE_ARTLS_SERVER | TYPE_COORDINATOR
     */
    public static final int PROFILE_TAG  			= 0x00001;
    public static final int PROFILE_BASE			= 0x00002;
    public static final int PROFILE_COORDINATOR 	= 0x00004;
    public static final int PROFILE_ARTLS_BASE		= 0x00010;
    public static final int PROFILE_ARTLS_SERVER	= 0x00020;

    /**
     * The Device Location rate supported : static,agile etc ..
     * Note : keep maskable as a device may have several capabilities
     */
    public static final int LOCRATE_STATIC  	= 0x00001;
    public static final int LOCRATE_AGILE 		= 0x00002;

    public static final int LOCRATE_SLOW = 0;
    public static final int LOCRATE_MEDIUM = 1;
    public static final int LOCRATE_FAST = 2;

    /**
     * The Device moving states : static,walking,running, etc ..
     */
	public static final int MOVSTATE_STATIC  	= 0x00001;
	public static final int MOVSTATE_SLOW_WALK  = 0x00002;	
	public static final int MOVSTATE_FAST_WALK  = 0x00004;
	public static final int MOVSTATE_SLOW_RUN  	= 0x00008;
	public static final int MOVSTATE_FAST_RUN  	= 0x00010;

}
