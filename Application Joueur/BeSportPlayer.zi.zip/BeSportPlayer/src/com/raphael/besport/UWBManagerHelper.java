package com.raphael.besport;

import com.bespoon.uwb.Uwb;
import com.bespoon.uwb.manager.UwbDevice;
import com.bespoon.uwb.manager.UwbManager;

import TagConnexion.TAGDevice;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class UWBManagerHelper implements UwbManager.UwbManagerListener  {
	
	private MainActivity myActivity;
	private final String TAG = "UWBManagerHelper";
	public UWBManagerHelper(MainActivity pA){
		this.myActivity = pA;
		
	}

	////  UwbManager.UwbManagerListener
	@Override
	public void onUWBManagerCreated(UwbManager manager) {
		// TODO Auto-generated method stub
		 // Check Local adapter is turned on, otherwise, launch admin app to allow user to turn it on
        if ((manager.getEnableState() != Uwb.ENABLE_STATE_ON) && (manager.getRadioState() != Uwb.RADIO_STATE_ON)) {
        	
        	Intent enablerIntent = new Intent();
            enablerIntent.setClassName("com.bespoon.uwb", "com.bespoon.uwb.admin.EnablerActivity");
            
            try {
            	this.myActivity.startActivity(enablerIntent);
                
            }
            catch (ActivityNotFoundException e) {
                Toast.makeText(this.myActivity, "marche pas exeption", Toast.LENGTH_LONG).show();
            }
        }
        this.myActivity.mUwbAttachedDevices = manager.getAttachedDevices();
	}
	@Override
    public void onUwbEnableStateChanged(int prevState, int newState) {
        if ((newState != Uwb.ENABLE_STATE_ON) && (newState != Uwb.ENABLE_STATE_TURNING_ON)) {
           Toast.makeText(this.myActivity, "onUwbEnableStateChanged", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onUwbRadioStateChanged(int prevState, int newState) {
        if ((newState != Uwb.RADIO_STATE_ON) && (newState != Uwb.RADIO_STATE_TURNING_ON)) {
            Toast.makeText(this.myActivity, "onUwbEnableStateChanged + off", Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    public void onUwbDeviceAttached(UwbDevice device) {
    	this.myActivity.mUwbAttachedDevices.add(device);
        if(!this.myActivity.myTagHandler.containsTAG(device)){
        	this.myActivity.myTagHandler.addTag(new TAGDevice(device,this.myActivity.getDeviceIdentity(device)));
            device.registerListener(this.myActivity.getUwbDeviceListener());
            this.myActivity.nbAttachedDevice++;
            Toast.makeText(this.myActivity, this.myActivity.nbAttachedDevice +"device(s) Attached ", Toast.LENGTH_LONG).show();
        	Log.i(TAG,(this.myActivity).getDeviceIdentity(device)+" attached");

        	this.myActivity.updateTagInfos();
        }
    }
    
    @Override
    public void onUwbDeviceDetached(UwbDevice device) {
    	this.myActivity.mUwbAttachedDevices.remove(device);
    	this.myActivity.myTagHandler.removeTag(device);
        device.unregisterListener(this.myActivity.getUwbDeviceListener());
        this.myActivity.nbAttachedDevice--;
        Toast.makeText(this.myActivity, "device detached => "+ this.myActivity.nbAttachedDevice +"device(s) Attached now", Toast.LENGTH_SHORT).show();
        this.myActivity.updateTagInfos();
    }
	@Override
	public void onUWBManagerDestroyed(UwbManager arg0) {
		// TODO Auto-generated method stub	
	}
    

}
