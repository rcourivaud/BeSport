package algorithmes;

import java.util.ArrayList;


public class Point{

    private Double x;
    private Double y;
    private Double z;
    private ArrayList<Point> tabPoint;
    //private String TAG = "Point";

    //Constructeur du point joueur
    public Point(ArrayList<Point> pTabPoint)
    {
        this.tabPoint = pTabPoint;
        this.x = 0.0;
        this.y = 0.0;
        this.z = 0.0;
    }


    //Constructeur du point tag origine
    public Point()
    {
        this.x = 0.0;
        this.y = 0.0;
        this.z = 0.0;
    }
    

    
    //Constructeur d'un point tag
    public Point(Double x, Double y, Double z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }




    //Fonction Update des coordonn�es d'un point
    public void updatePoint(ArrayList<Double> tabDist)
    {
    	//System.out.println("tabDist :" + tabDist.toString());
    	//System.out.println("tabPoint :" + tabPoint.toString());
        double[][] A =new double[tabPoint.size()-1][3];
        double[][] b =new double[tabPoint.size()-1][1];
        int i, j;

        /*
        Il est possible de d�commenter certaines lignes pour faire apparaitre les matrices
        g�n�r�es, ainsi que les �tapes du calcul
         */

        //              CREATION DE LA MATRICE A

        for(i=0; i<A.length; i++) {
            for(j=0; j<A[i].length; j++) {
                if (j == 0){
                    A[i][j] = 2*(tabPoint.get(i+1).x-tabPoint.get(0).x);
                }
                else if (j == 1){
                    A[i][j] = 2*(tabPoint.get(i+1).y-tabPoint.get(0).y);
                }
                else{
                    A[i][j] = 2*(tabPoint.get(i+1).z-tabPoint.get(0).z);
                }
            }
        }

        Matrix AMatrix = new Matrix (A);
        //System.out.println("A :");
        //AMatrix.print(3,2);

        //             CREATION DE LA MATRICE b

        for(i=0; i<b.length; i++) {
            Point zero = tabPoint.get(0);
            Point actif = tabPoint.get(i+1);
            b[i][0] = (Math.pow(tabDist.get(0),2.0)-Math.pow(tabDist.get(i+1),2.0)+
            Math.pow(actif.x,2.0)+Math.pow(actif.y,2.0)+Math.pow(actif.z,2.0)-
            Math.pow(zero.x,2.0)-Math.pow(zero.y,2.0)-Math.pow(zero.z,2.0));
        }

        //            CALCUL ALGO DE TRILATERATION

        Matrix bMatrix = new Matrix(b);
        //System.out.println("b :");
        //bMatrix.print(1,2);

        /* Formule : (AMT*AM)^-1*AMT*b */
        Matrix AMatrixTranspose = AMatrix.transpose();
        //System.out.println("AMT :");
        //AMatrixTranspose.print(3,2);

        Matrix AMTxAM = AMatrixTranspose.times(AMatrix);
        //System.out.println("AMTxA :");
        //AMTxAM.print(3,2);

        //Log.d(TAG, AMTxAM.toString());
        Matrix inverseAMTxAM = AMTxAM.inverse();
        //System.out.println("(AMTxA)^-1");
        //inverseAMTxAM.print(2, 6);

        Matrix mult1 = inverseAMTxAM.times(AMatrixTranspose);
        //System.out.println("(AMT*AM)^-1*AMT :");
        //mult1.print(3,2);

        Matrix result = mult1.times(bMatrix);
        //System.out.println("(AMT*AM)^-1*AMT*b :");
        //result.print(3,2);

        int resultCol = result.getColumnDimension();
        int resultRow = result.getRowDimension();





        //             COORDONNEES DU POINT

        this.x = result.get(resultRow-3,resultCol-1);
        this.y = result.get(resultRow-2,resultCol-1);
        this.z = result.get(resultRow-1,resultCol-1);
    }

    //  ACCESSEUR
    public double getX()
    {
        return this.x;
    }

    public double getY()
    {
        return this.y;
    }

    public double getZ()
    {
        return this.z;
    }


    @Override
    public String toString(){
    	return "" + this.x + "," + this.y + "," + this.z;
    	
    }
    
}
