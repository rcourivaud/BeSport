package TagConnexion;

import com.bespoon.uwb.manager.UwbDevice;

public class TAGDevice {
	
	private UwbDevice myUwbTag;
	private String aTagName;
	private double aTagDistance;
	
	public TAGDevice(UwbDevice pD, String pName){
		this.myUwbTag = pD;
		this.aTagName = pName;
		this.aTagDistance = 0.0;
	}
	
	public void updateDistance(double newDist){
		this.aTagDistance = newDist;
	}

	public UwbDevice getMyUwbTag() {
		return myUwbTag;
	}

	public String getaTagName() {
		return aTagName;
	}

	public double getaTagDistance() {
		return aTagDistance;
	}
}
