/**
 *                          OpenSplice Mobile
 *
 *    This software and documentation are Copyright 2010 to 2013 PrismTech
 *    Limited and its licensees. All rights reserved. See file:
 *
 *                           docs/LICENSE.html
 *
 *    for full copyright notice and license terms.
 */
package com.raphael.besport;

public class Config {
    /**
     * The bootstrap class name, used for DDS initialization with OpenSplice Mobile.
     */
    public static final String DDS_BOOTSTRAP_CLASS = "org.opensplice.mobile.core.ServiceEnvironmentImpl";

    /**
     * The DDS DomainId this example is using.
     */
    public static final int    DDS_DOMAIN_ID       = 0;

    /**
     * The Topic name this example is using.
     */
    public static final String DDS_TOPIC_NAME      = "HelloWorldData_Msg";

    /**
     * The default user name.
     */
    public static final String DEFAULT_USER_NAME   = "andro";

    /**
     * A tag of used for logging purpose.
     */
    public static final String LOGGING_TAG   = "ChatMainActivity";
}
