package com.example.dds_test;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;

import org.omg.dds.sub.DataReader;

import HelloWorldData.Msg;

public class MyStatsFragment extends Fragment {

    private String TAG = "MyStatsFragment.class";
    private MainActivity aMainActivity;
    private DataReader<Msg> MsgReader;
    private String aStringRecup="";

    public MyStatsFragment() {
    }


    public static ListView maListViewPerso;
    public static ListView opponentTeamView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_my_stats, container, false);
        this.aMainActivity = ((MainActivity)getActivity());
        this.createListView(v);
        return v;
    }

    public void createListView(View view){
        this.maListViewPerso = (ListView) view.findViewById(R.id.listviewmyteam);
        this.opponentTeamView = (ListView) view.findViewById(R.id.listviewopponentteam);

        /*ArrayList<HashMap<String, String>> listItemPerso =  this.aMainActivity.getMyTeam().getListForDisplay();
        ArrayList<HashMap<String, String>> listItemOpponent =  this.aMainActivity.getOpponentTeam().getListForDisplay();

        SimpleAdapter mSchedule = new SimpleAdapter (this.getActivity().getBaseContext(), listItemPerso, R.layout.display_player_stat,
                new String[] {"img", "playername", "vitesse", "hauteur", "distanceparcourue", "playernumero"},
                new int[] {R.id.img, R.id.playername, R.id.vitesse, R.id.hauteur, R.id.distanceparcourue, R.id.numero});

        SimpleAdapter mSchedule2 = new SimpleAdapter (this.getActivity().getBaseContext(), listItemOpponent, R.layout.display_player_stat_otherteam,
                new String[] {"img", "playername", "vitesse", "hauteur", "distanceparcourue", "playernumero"},
                new int[] {R.id.img, R.id.playername, R.id.vitesse, R.id.hauteur, R.id.distanceparcourue, R.id.numero});*/

        this.maListViewPerso.setAdapter(this.aMainActivity.mSchedule);
        this.opponentTeamView.setAdapter(this.aMainActivity.mSchedule2);

        /*maListViewPerso.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            @SuppressWarnings("unchecked")
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                HashMap<String, String> map = (HashMap<String, String>) maListViewPerso.getItemAtPosition(position);
                AlertDialog.Builder adb = new AlertDialog.Builder(Tutoriel5_Android.this);
                adb.setTitle("Sélection Item");
                adb.setMessage("Votre choix : "+map.get("titre"));
                adb.setPositiveButton("Ok", null);
                adb.show();
            }
        });*/


        if(this.aMainActivity.mSchedule.getCount() > 3){
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) this.maListViewPerso.getLayoutParams();
            lp.height = 500;
            this.maListViewPerso.setLayoutParams(lp);

        }




    }



}
