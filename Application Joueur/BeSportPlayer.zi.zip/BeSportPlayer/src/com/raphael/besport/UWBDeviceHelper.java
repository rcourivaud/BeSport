package com.raphael.besport;

import com.bespoon.uwb.manager.UwbDevice;

import android.widget.Toast;

public class UWBDeviceHelper implements UwbDevice.UwbDeviceListener{
	
	int flag =0;
	MainActivity myActivity;
	
	public UWBDeviceHelper(MainActivity pA){
		this.myActivity= pA;		
	}

	@Override
	public void onDistanceChanged(UwbDevice device, int accuracy, long timestamp, float distance) {
		
		//String data = "s=uwb,t=" + ((MainActivity)mCtx).getDeviceIdentity(device) + ",tu=" + timestamp + ",ts=" + System.currentTimeMillis() + ",d=" + distance + ",acy=" + accuracy;
		
		//Log.d(TAG, "timestamp : " + timestamp);
		flag += 1;
		int i = this.myActivity.mUwbAttachedDevices.indexOf(device);
		

		this.myActivity.myTagHandler.updateTagDistance(device, distance*100);
		//Log.d(TAG, "tabDist : " + this.myActivity.aTabDist.toString());		
		
		this.myActivity.aTabDist.set(i, (double)(distance*100));
		if(this.myActivity.nbAttachedDevice>3){
			if(flag%4==0){
				this.myActivity.myPlayer.updatePlayer(this.myActivity.aTabDist);

				this.myActivity.updatePlayerInfos();
				String vStrToSend = this.myActivity.myPlayer.createStringToSend();
				this.myActivity.sendStringToDDS(vStrToSend);

				/*if(flag%100==0){
					Toast.makeText(this, vStrToSend, Toast.LENGTH_LONG).show();
				}*/
			}
		}
		else{
			//Log.d(TAG,"Vous devez attacher au minimum 4 TAGs");
			if(flag%100==0){
				Toast.makeText(this.myActivity, "Vous devez attacher au minimum 4 TAGs", Toast.LENGTH_LONG).show();
			}
		}
		
		this.myActivity.updateTagInfos();
	}

	@Override
	public void onLocationChanged(UwbDevice device, int accuracy,
			long timestamp, float x, float y, float z) {
		// TODO Auto-generated method stub
		//Toast.makeText((Context)this, "Location changed = x="+x+" y="+y+" z="+z, Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onLost(UwbDevice device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onRecovered(UwbDevice device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onLocationProfileChanged(UwbDevice device, int prevProfile,
			int newProfile, int status) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onBatteryLevelChanged(UwbDevice device, int prevLevel,
			int newLevel) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onBatteryStateChanged(UwbDevice device, boolean isLow) {
		// TODO Auto-generated method stub
		
	}

}
