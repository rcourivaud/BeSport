package algorithmes;


import java.util.ArrayList;
import java.util.HashMap;

import com.raphael.besport.MainActivity;

import android.util.Log;

public class Joueur {
	private String aName;
	private String aNum;
	private String aTeam;
	private Point coord;
	private Vitesse vitesse;
	private Double hauteur;
    private ArrayList<Point> tabPoint;
    private Point lastPoint;
    private Double distance;
    
    private MainActivity myActivity;
    
    private String TAG = "Joueur";

	public Joueur (Point p, Vitesse v, Double h){
		this.coord = p;
		this.vitesse = v;
		this.hauteur = h;
        this.distance = 0.0;
	}

    public Joueur(String pName, String pNum, String pTeam, ArrayList<Point> pTabPoint, MainActivity pActivity){
        this.tabPoint = pTabPoint;
        //this.coord = new Point();
        this.coord = new Point(tabPoint);
        this.vitesse = new Vitesse();
        this.hauteur = this.coord.getZ();
        this.distance = 0.0;
        
        this.aName = pName;
        this.aNum = pNum;
        this.myActivity = pActivity;
        this.aTeam = pTeam;
    }

    public void updatePlayer(ArrayList<Double> newTabDist){
    	for(Double mD: newTabDist){
    		if(mD == 0.0){
    			return;
    		}
    	}
    	
    	//Premier Point Initialisation du joueur
   	 	if(this.lastPoint == null){
   	 		this.coord.updatePoint(newTabDist);
   	 		this.lastPoint = new Point(this.coord.getX(), this.coord.getY(), this.coord.getZ());
   	 	}
   	 	//Deuxieme Point 
   	 	else{
   	 		this.lastPoint = new Point(this.coord.getX(), this.coord.getY(), this.coord.getZ());
   	 		this.coord.updatePoint(newTabDist);		 
   	 	}
    	
    	this.coord.updatePoint(newTabDist);
        this.updateHauteur();
        this.updateVitesse();
        this.updateDistance();
    }
    
    private void updateVitesse(){
		this.vitesse.updateVitesse(this.coord);
		Log.d(TAG, "Vitesse :" + this.vitesse);
    }
    
    public void updateDistance(){
    	Point VN2 = this.lastPoint;
    	Point VN1 = this.coord;
    	double tmp = this.distance;
        this.distance =  tmp + this.calculDistance(VN1.getX(), VN1.getY(),VN2.getX(),VN2.getY());
    	Log.d(TAG, "Distance : " + this.distance);
    }
    
    public double calculDistance(double x1, double y1, double x2, double y2) {
        return Math.sqrt(sqr(y2 - y1) + sqr(x2 - x1));
    } 
    
    static public double sqr(double a) {
        return a*a;
    } 
    
    private void updateHauteur(){
        this.hauteur = this.coord.getZ();
    }
    public Double getX(){
        return this.coord.getX();
    }
    public Double getY(){
        return this.coord.getY();
    }
    public Point getPoint()
    {
        return this.coord;
    }
    public Double getHauteur()
    {
        return this.hauteur;
    }
    public Vitesse getVitesse()
    {
        return this.vitesse;
    }
    
    public ArrayList<HashMap<String,String>> getMapForDisplay(){
		ArrayList<HashMap<String, String>> listItem = new ArrayList<HashMap<String, String>>();
        HashMap<String,String> map = new HashMap<String,String>();
        

        map.put("stat", "X : ");
        map.put("value", "" + this.coord.getX());
        listItem.add(map);
        
        map = new HashMap<String,String>();
        map.put("stat", "Y : ");
        map.put("value", "" + this.coord.getY());
        listItem.add(map);
        
        map = new HashMap<String,String>();
        map.put("stat", "Vitesse : ");
        map.put("value", "" + this.vitesse.getVitesse());
        listItem.add(map);
        
       map = new HashMap<String,String>();
        map.put("stat", "Hauteur : ");
        map.put("value", "" + this.hauteur);
        listItem.add(map);
        
        map = new HashMap<String,String>();
        map.put("stat", "Distance :");
        map.put("value", "" + this.distance);
        listItem.add(map);
        
        return listItem;    	
    }
    
	private String convertPourcentage(Point p){
        double x = p.getX();
        double y = p.getY();

        int newX = (int) (x/this.myActivity.aLargeur);
        int newY = (int) (y/this.myActivity.aLongueur);

        return "" + newX + "-" + newY;
    }
	
	public String createStringToSend(){		
		String vCoordString = this.convertPourcentage(this.coord);
		return this.aName + "-" + this.aNum + "-" + this.aTeam + "-" + vCoordString + "-" + this.coord.getZ() + "-" +
				this.vitesse.getVitesse() + "-" + this.distance.toString();
	}

	public String getaName() {
		return aName;
	}

	public String getaNum() {
		return aNum;
	}

	public String getaTeam() {
		return aTeam;
	}

	
	
}
