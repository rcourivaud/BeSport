package com.example.dds_test;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by Nicolas on 17/12/2015.
 * Cette classe sert à afficher en temps réel les points detectés
 */
public class Affichage extends View {

    private String TAG = "AffichageClass";
    private MainActivity aMainActivity;

    private int xSize;
    private int ySize;
    private float pointRadius; //taille du point
    private Paint aPaint;
    private Random aRandom;
    private Boolean key = true; //permet de n'appeler qu'une seule fois à qqch dans onDraw (pas utilisé encore)
    private Boolean drawingMode = false; //permet de figer l'écran
    private double resizeCoef = 0.07; // à modifier en fonction du sport

    //gestion de l'image du player
    private GestureDetector gestureDetector;
    private Drawable playerDrawable;
    private BitmapDrawable playerBitmap;
    private int team1, team2;
    private List<Player> aListTampon1, aListTampon2;

    //Gestion du mode Draw
    private Paint mPaint;
    private Paint mBitmapPaint;
    private Paint circlePaint;
    private Bitmap  mBitmap;
    private Canvas  mCanvas;
    private Path mPath;
    private Path circlePath;
    private float mX, mY;
    private static final float TOUCH_TOLERANCE = 4;

    //DrawingPanel (boutons)
    private RelativeLayout drawingPanel;
    private ImageButton drawButton;
    private ImageButton screenButton;
    private ImageButton refreshButton;



    public Affichage(Context context) {
        super(context);
        Log.d(TAG, "Constructor1");
        this.aMainActivity = (MainActivity) context;
        this.initPaint();
        this.gestureDetector = new GestureDetector(context, new GestureListener());
        this.playerDrawable = this.aMainActivity.getaPLayerDrawable();

        this.team1 = this.aMainActivity.getMyTeam().getTeamColor();
        this.team2 = this.aMainActivity.getOpponentTeam().getTeamColor();
        this.aListTampon1 = new ArrayList<>();
        this.aListTampon2 = new ArrayList<>();

        this.initDrawingPaint();
        this.mPath = new Path();
        this.initDrawingPanel();
    }

    public Affichage(Context context, AttributeSet attrs) {
        super(context, attrs);
        Log.d(TAG, "Constructor2");
        this.aMainActivity = (MainActivity) context;
        this.aRandom = new Random();//a retirer plus tard
        this.initPaint();
        this.gestureDetector = new GestureDetector(context, new GestureListener());
        this.playerDrawable = this.aMainActivity.getaPLayerDrawable();

        this.team1 = this.aMainActivity.getMyTeam().getTeamColor();
        this.team2 = this.aMainActivity.getOpponentTeam().getTeamColor();
        this.aListTampon1 = new ArrayList<>();
        this.aListTampon2 = new ArrayList<>();

        this.initDrawingPaint();
        this.mPath = new Path();
        this.initDrawingPanel();
    }

    public Affichage(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        Log.d(TAG, "Constructor3");
        this.aMainActivity = (MainActivity) context;
        this.initPaint();
        this.gestureDetector = new GestureDetector(context, new GestureListener());
        this.playerDrawable = this.aMainActivity.getaPLayerDrawable();

        this.team1 = this.aMainActivity.getMyTeam().getTeamColor();
        this.team2 = this.aMainActivity.getOpponentTeam().getTeamColor();
        this.aListTampon1 = new ArrayList<>();
        this.aListTampon2 = new ArrayList<>();

        this.initDrawingPaint();
        this.mPath = new Path();
        this.initDrawingPanel();
    }

    private void initPaint(){
        this.aPaint = new Paint();
        this.aPaint.setColor(Color.BLUE);
        this.aPaint.setAntiAlias(true);
    }

    private void initDrawingPaint(){
        this.mPaint = new Paint();
        this.mPaint.setAntiAlias(true);
        this.mPaint.setDither(true);
        this.mPaint.setColor(Color.RED);
        this.mPaint.setStyle(Paint.Style.STROKE);
        this.mPaint.setStrokeJoin(Paint.Join.ROUND);
        this.mPaint.setStrokeCap(Paint.Cap.ROUND);
        this.mPaint.setStrokeWidth(8);

        this.initSecondaryPaint();
    }

    private void initSecondaryPaint(){
        this.mBitmapPaint = new Paint(Paint.DITHER_FLAG);
        this.circlePaint = new Paint();
        this.circlePath = new Path();
        this.circlePaint.setAntiAlias(true);
        this.circlePaint.setColor(Color.BLUE);
        this.circlePaint.setStyle(Paint.Style.STROKE);
        this.circlePaint.setStrokeJoin(Paint.Join.MITER);
        this.circlePaint.setStrokeWidth(4f);
    }

    private void initSizeView(Canvas canvas){
        xSize = canvas.getWidth();
        ySize = canvas.getHeight();
        this.pointRadius = (float) (xSize*0.015);
    }

    @Override
    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);

        // A ne faire qu'une seule fois
        if(this.key){
            this.initSizeView(canvas);
            this.key = false;
            Log.d("onDraw", "Size initialized");
        }

        this.playerBitmap = (BitmapDrawable) this.resize(this.playerDrawable, xSize); //création et resize du logo du joueur

        if(this.drawingMode == false) {
            //JUST FOR TEST
            //Faire le lien ici avec les objets Player des Team
            for (Player p : this.aMainActivity.getMyTeam().getaPlayerList()) {
                //canvas.drawCircle(p.x, p.y, this.pointRadius, aPaint);
                this.setIconColor(this.team1);
                int x1 = p.getPosition().x;
                int y1 = p.getPosition().y;
                canvas.drawBitmap(this.playerBitmap.getBitmap(), x1 * (xSize/100), y1 * (ySize/100), null);
                if (this.aMainActivity.getShowName()) {
                    canvas.drawText(p.getaName(), x1 * (xSize/100) + (this.playerBitmap.getBitmap().getHeight() / 5), (float) (y1 * (ySize/100) + (this.playerBitmap.getBitmap().getHeight() * 1.3)), this.aPaint); //recup le nom du joueur
                }



                //déplacement random
                /*int x = (this.aRandom.nextInt(2) * 2 - 1) * 3;
                int y = (this.aRandom.nextInt(2) * 2 - 1) * 3;
                p.getPosition().x += x;
                p.getPosition().y += y;*/

            }
            for (Player p : this.aMainActivity.getOpponentTeam().getaPlayerList()) {
                //canvas.drawCircle(p.x, p.y, this.pointRadius, aPaint);
                this.setIconColor(this.team2);
                int x1 = p.getPosition().x;
                int y1 = p.getPosition().y;
                canvas.drawBitmap(this.playerBitmap.getBitmap(), x1 * (xSize/100), y1 * (ySize/100), null);
                if (this.aMainActivity.getShowName()) {
                    canvas.drawText(p.getaName(), x1 * (xSize/100) + (this.playerBitmap.getBitmap().getHeight() / 5), (float) (y1 * (ySize/100) + (this.playerBitmap.getBitmap().getHeight() * 1.3)), this.aPaint); //recup le nom du joueur
                }

                //déplacement random
                /*int x = (this.aRandom.nextInt(2) * 2 - 1) * 3;
                int y = (this.aRandom.nextInt(2) * 2 - 1) * 3;
                p.getPosition().x += x;
                p.getPosition().y += y;*/

            }
        }
        else{
            for(Player p : this.aListTampon1){
                this.setIconColor(this.team1);
                int x1 = p.getPosition().x;
                int y1 = p.getPosition().y;
                canvas.drawBitmap(this.playerBitmap.getBitmap(), x1 * (xSize/100), y1 * (ySize/100), null);
                if (this.aMainActivity.getShowName()) {
                    canvas.drawText(p.getaName(), x1 * (xSize/100) + (this.playerBitmap.getBitmap().getHeight() / 5), (float) (y1 * (ySize/100) + (this.playerBitmap.getBitmap().getHeight() * 1.3)), this.aPaint); //recup le nom du joueur
                }
            }
            for(Player p : this.aListTampon2){
                this.setIconColor(this.team2);
                int x1 = p.getPosition().x;
                int y1 = p.getPosition().y;
                canvas.drawBitmap(this.playerBitmap.getBitmap(), x1 * (xSize/100), y1 * (ySize/100), null);
                if (this.aMainActivity.getShowName()) {
                    canvas.drawText(p.getaName(), x1 * (xSize/100) + (this.playerBitmap.getBitmap().getHeight() / 5), (float) (y1 * (ySize/100) + (this.playerBitmap.getBitmap().getHeight() * 1.3)), this.aPaint); //recup le nom du joueur
                }
            }

            canvas.drawBitmap( mBitmap, 0, 0, this.mBitmapPaint);
            canvas.drawPath(mPath, this.mPaint);
            canvas.drawPath( circlePath,  this.circlePaint);
            invalidate(); //???????????????????
        }


        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            Log.e(TAG, e.toString());
        }
        //this.invalidate(xMove - 3*((int) this.pointRadius), xMove - 3*((int) this.pointRadius), xMove + 3*((int) this.pointRadius), xMove + 3*((int) this.pointRadius));  // Force redrew
        if(!this.drawingMode){
            this.invalidate();
        }
    }

    private Drawable resize(Drawable image, int size) {
        size *= this.resizeCoef;
        Bitmap b = ((BitmapDrawable)image).getBitmap();
        Bitmap bitmapResized = Bitmap.createScaledBitmap(b, size, size, false);
        return new BitmapDrawable(getResources(), bitmapResized);
    }

    private BitmapDrawable flip(BitmapDrawable d){
        Matrix m = new Matrix();
        m.preScale(-1, 1);
        Bitmap src = d.getBitmap();
        Bitmap dst = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, false);
        dst.setDensity(DisplayMetrics.DENSITY_DEFAULT);
        return new BitmapDrawable(dst);
    }

    private void setIconColor(int color) {
        if (color == 0) {color = 0xffffffff;}
        final Resources res = getResources();

        Bitmap maskBitmap = ((BitmapDrawable) this.playerBitmap).getBitmap();
        final int width = maskBitmap.getWidth();
        final int height = maskBitmap.getHeight();

        Bitmap outBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(outBitmap);
        canvas.drawBitmap(maskBitmap, 0, 0, null);

        Paint maskedPaint = new Paint();
        maskedPaint.setColor(color);
        maskedPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));

        canvas.drawRect(0, 0, width, height, maskedPaint);

        BitmapDrawable outDrawable = new BitmapDrawable(res, outBitmap);
        this.playerBitmap = outDrawable;
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();


        if(this.aMainActivity.getAbleToDraw()){
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    touch_start(x, y);
                    invalidate();
                    break;
                case MotionEvent.ACTION_MOVE:
                    touch_move(x, y);
                    invalidate();
                    break;
                case MotionEvent.ACTION_UP:
                    touch_up();
                    invalidate();
                    break;
            }
        }
        return this.gestureDetector.onTouchEvent(event);
    }
    private class GestureListener extends GestureDetector.SimpleOnGestureListener {
        @Override
        public boolean onDown(MotionEvent e) {
            return true;
        }
        @Override
        public boolean onDoubleTap(MotionEvent e) {
            float x = e.getX();
            float y = e.getY();

            if(aMainActivity.getAbleToDraw()){
                aMainActivity.enableDraw(aMainActivity.findViewById(R.id.drawButton));

            }
            drawingMode = !drawingMode;

            if(drawingMode == true) {
                Toast toast = Toast.makeText(aMainActivity, "Draw your strategie", Toast.LENGTH_SHORT);
                toast.show();
                //Sauvegarde des positions lors de la mise en pause
                for(Player p : aMainActivity.getMyTeam().getaPlayerList()) {
                    aListTampon1.add(p);
                }
                for(Player p : aMainActivity.getOpponentTeam().getaPlayerList()) {
                    aListTampon2.add(p);
                }
                setDrawingPanelVisibility(true);
            }
            else {
                setDrawingPanelVisibility(false);
            }



//            Log.d(TAG, "Double Tap at Coord: (" + x + "," + y + ")");

//            touch_start(x, y);

            return true;
        }
    }


    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmap);
    }

    private void touch_start(float x, float y) {
        Log.d(TAG, "touch_start");
        this.mPath.reset();
        this.mPath.moveTo(x, y);
        this.mX = x;
        this.mY = y;
    }

    private void touch_move(float x, float y) {
        //Log.d(TAG, "touch_move");
        setDrawingPanelVisibility(false);
        float dx = Math.abs(x - this.mX);
        float dy = Math.abs(y - this.mY);
        if (dx >= this.TOUCH_TOLERANCE || dy >= this.TOUCH_TOLERANCE) {
            this.mPath.quadTo(this.mX, this.mY, (x + this.mX)/2, (y + this.mY)/2);
            this.mX = x;
            this.mY = y;

            this.circlePath.reset();
            this.circlePath.addCircle(this.mX, this.mY, 45, Path.Direction.CW);
        }
    }

    private void touch_up() {
        Log.d(TAG, "touch_up");
        setDrawingPanelVisibility(true);
        this.mPath.lineTo(mX, mY);
        this.circlePath.reset();
        // commit the path to our offscreen
        this.mCanvas.drawPath(this.mPath, this.mPaint);
        // kill this so we don't double draw
        this.mPath.reset();
    }

    private void initDrawingPanel(){
        this.drawButton = (ImageButton) this.aMainActivity.findViewById(R.id.drawButton);
        this.screenButton = (ImageButton) this.aMainActivity.findViewById(R.id.screenButton);
        this.refreshButton = (ImageButton) this.aMainActivity.findViewById(R.id.refreshButton);
        this.drawingPanel = (RelativeLayout) this.aMainActivity.findViewById(R.id.drawingPanel);

        Log.d(TAG, "drawButton " + this.drawButton);
        Log.d(TAG, "screenButton " + this.screenButton);
        Log.d(TAG, "refreshButton " + this.refreshButton);

//        this.drawButton.setMaxWidth((int) (this.getWidth()*0.001));
//        this.screenButton.setMaxWidth((int) (this.getWidth() * 0.001));
//        this.refreshButton.setMaxWidth((int) (this.getWidth() * 0.001));

    }

    public void setDrawingPanelVisibility(Boolean visible){
        if(visible == true){
            this.drawingPanel.setVisibility(VISIBLE);
        }
        else {
            this.drawingPanel.setVisibility(INVISIBLE);
        }
    }


}
