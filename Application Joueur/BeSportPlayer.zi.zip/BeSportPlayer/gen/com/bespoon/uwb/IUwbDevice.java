/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\Users\\rcour\\workspace\\Base_UWB\\BeSportPlayer\\src\\com\\bespoon\\uwb\\IUwbDevice.aidl
 */
package com.bespoon.uwb;
public interface IUwbDevice extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.bespoon.uwb.IUwbDevice
{
private static final java.lang.String DESCRIPTOR = "com.bespoon.uwb.IUwbDevice";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.bespoon.uwb.IUwbDevice interface,
 * generating a proxy if needed.
 */
public static com.bespoon.uwb.IUwbDevice asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.bespoon.uwb.IUwbDevice))) {
return ((com.bespoon.uwb.IUwbDevice)iin);
}
return new com.bespoon.uwb.IUwbDevice.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_registerListener:
{
data.enforceInterface(DESCRIPTOR);
com.bespoon.uwb.IUwbDeviceListener _arg0;
_arg0 = com.bespoon.uwb.IUwbDeviceListener.Stub.asInterface(data.readStrongBinder());
this.registerListener(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_unregisterListener:
{
data.enforceInterface(DESCRIPTOR);
com.bespoon.uwb.IUwbDeviceListener _arg0;
_arg0 = com.bespoon.uwb.IUwbDeviceListener.Stub.asInterface(data.readStrongBinder());
this.unregisterListener(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_getBondingCapabilities:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getBondingCapabilities();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getBondState:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getBondState();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_isBonded:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.isBonded();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_isAttached:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.isAttached();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getMacAddress:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getMacAddress();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getShortAddress:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getShortAddress();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getHardwareVersion:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getHardwareVersion();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getFirmwareVersion:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getFirmwareVersion();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_setName:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
this.setName(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_getName:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getName();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getBatteryLevel:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getBatteryLevel();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_isLowBattery:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.isLowBattery();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_isMoving:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.isMoving();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getMovingState:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getMovingState();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_hasNetworkAccess:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.hasNetworkAccess();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_hasGsmAccess:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.hasGsmAccess();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getSupportedLocationProfiles:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getSupportedLocationProfiles();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getLocationProfile:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getLocationProfile();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getSupportedLocationRate:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getSupportedLocationRate();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getLocationRate:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getLocationRate();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_setLocationProfile:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _result = this.setLocationProfile(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_setLocationRate:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _result = this.setLocationRate(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getSupportedSensor:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getSupportedSensor();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getSensorInfo:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
float[] _arg1;
_arg1 = data.createFloatArray();
float[] _arg2;
_arg2 = data.createFloatArray();
this.getSensorInfo(_arg0, _arg1, _arg2);
reply.writeNoException();
return true;
}
case TRANSACTION_getSensorValue:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
long _arg2;
_arg2 = data.readLong();
float[] _arg3;
_arg3 = data.createFloatArray();
this.getSensorValue(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
return true;
}
case TRANSACTION_sendData:
{
data.enforceInterface(DESCRIPTOR);
byte[] _arg0;
_arg0 = data.createByteArray();
this.sendData(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_getSecureKey:
{
data.enforceInterface(DESCRIPTOR);
byte[] _arg0;
int _arg0_length = data.readInt();
if ((_arg0_length<0)) {
_arg0 = null;
}
else {
_arg0 = new byte[_arg0_length];
}
this.getSecureKey(_arg0);
reply.writeNoException();
reply.writeByteArray(_arg0);
return true;
}
case TRANSACTION_setSecureKey:
{
data.enforceInterface(DESCRIPTOR);
byte[] _arg0;
_arg0 = data.createByteArray();
this.setSecureKey(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_getMacInfoItStart:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getMacInfoItStart();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getMacInfoItSlot:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getMacInfoItSlot();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.bespoon.uwb.IUwbDevice
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public void registerListener(com.bespoon.uwb.IUwbDeviceListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_registerListener, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void unregisterListener(com.bespoon.uwb.IUwbDeviceListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_unregisterListener, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
//********************************************************************************
//*************************  	Pairing control 	******************************
//********************************************************************************
/**
     * Returns the device bonding capabilities (STANDARD,SECURE etc...)
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
@Override public int getBondingCapabilities() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getBondingCapabilities, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Get the bond state of the remote device.
     * <p>Possible values for the bond state are:
     * {@link #BOND_NONE},
     * {@link #BOND_BONDING},
     * {@link #BOND_BONDED}.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}.
     *
     * @return the bond state
	*/
@Override public int getBondState() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getBondState, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Returns true if the device has done successfully all the bonding process
	 * It can now attach/detach with the master
     * <p>Equivalent to:
     * <code>getBondState() == BOND_BONDED</code>
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
@Override public boolean isBonded() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_isBonded, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Returns true if the device has done successfully all the attachment process
	 * It is now considered as "active"
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
@Override public boolean isAttached() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_isAttached, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//********************************************************************************
//*************************  	Device Infos	 	******************************
//********************************************************************************
/**
     * Returns the hardware address of the Device : 128bits .
     * <p>For example, "2001:0db8:0000:85a3:0000:0000:ac1f:8001".
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return UWB hardware address as string
     */
@Override public java.lang.String getMacAddress() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getMacAddress, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Returns the short (hashed) address of the device : 24bits .
     * <p>For example : 0x0be5d00b.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return UWB hardware address as string
     */
@Override public int getShortAddress() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getShortAddress, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Returns the Hardware version of the device : 5bits .
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return device hardware version
     */
@Override public int getHardwareVersion() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getHardwareVersion, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Returns the Firmware version of the device : 5bits .
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return device firmware version
     */
@Override public int getFirmwareVersion() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getFirmwareVersion, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Set a friendly name for this device.
     * Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     */
@Override public void setName(java.lang.String name) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(name);
mRemote.transact(Stub.TRANSACTION_setName, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * Retrieve the friendly name for this device.
     */
@Override public java.lang.String getName() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getName, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Returns the device battery level (0->100%).
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
@Override public int getBatteryLevel() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getBatteryLevel, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Returns if the device is in the low battery state .
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
@Override public boolean isLowBattery() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_isLowBattery, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Returns if the device is the moving or not .
     * <p>Equivalent to:
     * <code>getMovingState() != MOVSTATE_STATIC </code>
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
@Override public boolean isMoving() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_isMoving, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Get the device moving state.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
@Override public int getMovingState() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getMovingState, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Set if the device is moving or not .
	 * Only available for local adapter
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *//*void setMovingState(int moveState);*//**
     * The Device has network access ?
	 * tells if the device can used assisted pairing via IP connection
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
	*/
@Override public boolean hasNetworkAccess() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_hasNetworkAccess, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * The Device has GSM access ?
	 * tells if the device can used assisted pairing via GSM like network
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
	*/
@Override public boolean hasGsmAccess() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_hasGsmAccess, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Returns a bitmap of  location profiles supported by the device (TYPE_TAG,TYPE_BASE etc...)
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     * @return bitmap of device supported location profile
     */
@Override public int getSupportedLocationProfiles() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getSupportedLocationProfiles, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Returns the device currrent location profile (TYPE_TAG,TYPE_BASE etc...)
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
@Override public int getLocationProfile() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getLocationProfile, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Returns a bitmap of location rate supported by the device (STATIC,AGILE,LOW,etc...)
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     * @return bitmap of device supported location rates
     */
@Override public int getSupportedLocationRate() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getSupportedLocationRate, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Returns the device currrent LocRate (STATIC,AGILE,LOW,etc..)
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
@Override public int getLocationRate() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getLocationRate, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//********************************************************************************
//**********************  		Ranging control 	******************************
//********************************************************************************
/**
     * Set the Local adapter current profile.
     *
     * <p>This is an asynchronous call, it will return immediately.
     * Listen to {@link #onLocationProfilechanged()} to be notified when
     * the profile changed  and its result.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
	 * @param locationProfile : TYPE_TAG,TYPE_BASE etc..
     * @hide
     */
@Override public int setLocationProfile(int locationProfile) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(locationProfile);
mRemote.transact(Stub.TRANSACTION_setLocationProfile, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Set device Location Rate.
     *
     * <p>This is an asynchronous call, it will return immediately.
     * Listen to {@link #onLocationRatechanged()} to be notified when
     * the location rate changed  and its result.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
	 * @param locationRate : LOCRATE_SLOW|MEDIUM|FAST|STATIC|AGILE
     * @hide
     */
@Override public int setLocationRate(int locationRate) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(locationRate);
mRemote.transact(Stub.TRANSACTION_setLocationRate, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//********************************************************************************
//**********************  		Sensor control 		******************************
//********************************************************************************
/**
     * Returns a bitmap of sensors supported by the device
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
 	 * @return bitmap of supported sensors (TYPE_ACCELEROMETER,TYPE_GRAVITY, etc..)
     */
@Override public int getSupportedSensor() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getSupportedSensor, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Get the device sensor max range and resolution
	 * @param : sensor Android sensor type :
	 *  TYPE_ACCELEROMETER,TYPE_GRAVITY,TYPE_GYROSCOPE,TYPE_MAGNETIC_FIELD,TYPE_PRESSURE...
	 * @param  maxRange : maximum range of the sensor in the sensor's unit.
	 * @param  resolution : resolution of the sensor in the sensor's unit.
	 * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
@Override public void getSensorInfo(int sensor, float[] maxRange, float[] resolution) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(sensor);
_data.writeFloatArray(maxRange);
_data.writeFloatArray(resolution);
mRemote.transact(Stub.TRANSACTION_getSensorInfo, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * Get the device sensor last value
	 * @param sensor : Android sensor type
	 *  TYPE_ACCELEROMETER,TYPE_GRAVITY,TYPE_GYROSCOPE,TYPE_MAGNETIC_FIELD,TYPE_PRESSURE...
	 * @param  in sensor : the sensor we want to get data
	 * @param  out accuracy : the sensor last value accuracy
	 * @param  out timestamp : the sensor last value timestamp in nanosecond
	 * @param  out value : The length and contents of the value array depends on which sensor type is being monitored
	 * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
@Override public void getSensorValue(int sensor, int accuracy, long timestamp, float[] value) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(sensor);
_data.writeInt(accuracy);
_data.writeLong(timestamp);
_data.writeFloatArray(value);
mRemote.transact(Stub.TRANSACTION_getSensorValue, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
//********************************************************************************
//*************************  		Data control 	******************************
//********************************************************************************
/**
     * Send data to the remote device.
     *
     * <p>This is an asynchronous call, it will return immediately.
     * Listen to {@link #onDeviceDatasent()} to be notified when
     * the data are sent, and its result.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
	 * @param data : byte stream
     * @hide
     */
@Override public void sendData(byte[] data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByteArray(data);
mRemote.transact(Stub.TRANSACTION_sendData, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
//********************************************************************************
//*************************  	Secure control 		******************************
//********************************************************************************
/**
     * Get secure key from device.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * @hide
     */
@Override public void getSecureKey(byte[] key) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((key==null)) {
_data.writeInt(-1);
}
else {
_data.writeInt(key.length);
}
mRemote.transact(Stub.TRANSACTION_getSecureKey, _data, _reply, 0);
_reply.readException();
_reply.readByteArray(key);
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * set secure key of the device.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * @hide
     */
@Override public void setSecureKey(byte[] key) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByteArray(key);
mRemote.transact(Stub.TRANSACTION_setSecureKey, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
//********************************************************************************
//*************************  	 MAC control 		******************************
//********************************************************************************
/**
     * Get device current IT_start mac settings
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * @hide
     */
@Override public int getMacInfoItStart() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getMacInfoItStart, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Get device current IT_slot mac settings
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * @hide
     */
@Override public int getMacInfoItSlot() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getMacInfoItSlot, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_registerListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_unregisterListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_getBondingCapabilities = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_getBondState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_isBonded = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_isAttached = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_getMacAddress = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_getShortAddress = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_getHardwareVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_getFirmwareVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_setName = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_getName = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_getBatteryLevel = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
static final int TRANSACTION_isLowBattery = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
static final int TRANSACTION_isMoving = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
static final int TRANSACTION_getMovingState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
static final int TRANSACTION_hasNetworkAccess = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
static final int TRANSACTION_hasGsmAccess = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
static final int TRANSACTION_getSupportedLocationProfiles = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
static final int TRANSACTION_getLocationProfile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 19);
static final int TRANSACTION_getSupportedLocationRate = (android.os.IBinder.FIRST_CALL_TRANSACTION + 20);
static final int TRANSACTION_getLocationRate = (android.os.IBinder.FIRST_CALL_TRANSACTION + 21);
static final int TRANSACTION_setLocationProfile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 22);
static final int TRANSACTION_setLocationRate = (android.os.IBinder.FIRST_CALL_TRANSACTION + 23);
static final int TRANSACTION_getSupportedSensor = (android.os.IBinder.FIRST_CALL_TRANSACTION + 24);
static final int TRANSACTION_getSensorInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 25);
static final int TRANSACTION_getSensorValue = (android.os.IBinder.FIRST_CALL_TRANSACTION + 26);
static final int TRANSACTION_sendData = (android.os.IBinder.FIRST_CALL_TRANSACTION + 27);
static final int TRANSACTION_getSecureKey = (android.os.IBinder.FIRST_CALL_TRANSACTION + 28);
static final int TRANSACTION_setSecureKey = (android.os.IBinder.FIRST_CALL_TRANSACTION + 29);
static final int TRANSACTION_getMacInfoItStart = (android.os.IBinder.FIRST_CALL_TRANSACTION + 30);
static final int TRANSACTION_getMacInfoItSlot = (android.os.IBinder.FIRST_CALL_TRANSACTION + 31);
}
public void registerListener(com.bespoon.uwb.IUwbDeviceListener listener) throws android.os.RemoteException;
public void unregisterListener(com.bespoon.uwb.IUwbDeviceListener listener) throws android.os.RemoteException;
//********************************************************************************
//*************************  	Pairing control 	******************************
//********************************************************************************
/**
     * Returns the device bonding capabilities (STANDARD,SECURE etc...)
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
public int getBondingCapabilities() throws android.os.RemoteException;
/**
     * Get the bond state of the remote device.
     * <p>Possible values for the bond state are:
     * {@link #BOND_NONE},
     * {@link #BOND_BONDING},
     * {@link #BOND_BONDED}.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}.
     *
     * @return the bond state
	*/
public int getBondState() throws android.os.RemoteException;
/**
     * Returns true if the device has done successfully all the bonding process
	 * It can now attach/detach with the master
     * <p>Equivalent to:
     * <code>getBondState() == BOND_BONDED</code>
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
public boolean isBonded() throws android.os.RemoteException;
/**
     * Returns true if the device has done successfully all the attachment process
	 * It is now considered as "active"
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
public boolean isAttached() throws android.os.RemoteException;
//********************************************************************************
//*************************  	Device Infos	 	******************************
//********************************************************************************
/**
     * Returns the hardware address of the Device : 128bits .
     * <p>For example, "2001:0db8:0000:85a3:0000:0000:ac1f:8001".
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return UWB hardware address as string
     */
public java.lang.String getMacAddress() throws android.os.RemoteException;
/**
     * Returns the short (hashed) address of the device : 24bits .
     * <p>For example : 0x0be5d00b.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return UWB hardware address as string
     */
public int getShortAddress() throws android.os.RemoteException;
/**
     * Returns the Hardware version of the device : 5bits .
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return device hardware version
     */
public int getHardwareVersion() throws android.os.RemoteException;
/**
     * Returns the Firmware version of the device : 5bits .
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *
     * @return device firmware version
     */
public int getFirmwareVersion() throws android.os.RemoteException;
/**
     * Set a friendly name for this device.
     * Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     */
public void setName(java.lang.String name) throws android.os.RemoteException;
/**
     * Retrieve the friendly name for this device.
     */
public java.lang.String getName() throws android.os.RemoteException;
/**
     * Returns the device battery level (0->100%).
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
public int getBatteryLevel() throws android.os.RemoteException;
/**
     * Returns if the device is in the low battery state .
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
public boolean isLowBattery() throws android.os.RemoteException;
/**
     * Returns if the device is the moving or not .
     * <p>Equivalent to:
     * <code>getMovingState() != MOVSTATE_STATIC </code>
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
public boolean isMoving() throws android.os.RemoteException;
/**
     * Get the device moving state.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
public int getMovingState() throws android.os.RemoteException;
/**
     * Set if the device is moving or not .
	 * Only available for local adapter
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     *//*void setMovingState(int moveState);*//**
     * The Device has network access ?
	 * tells if the device can used assisted pairing via IP connection
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
	*/
public boolean hasNetworkAccess() throws android.os.RemoteException;
/**
     * The Device has GSM access ?
	 * tells if the device can used assisted pairing via GSM like network
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
	*/
public boolean hasGsmAccess() throws android.os.RemoteException;
/**
     * Returns a bitmap of  location profiles supported by the device (TYPE_TAG,TYPE_BASE etc...)
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     * @return bitmap of device supported location profile
     */
public int getSupportedLocationProfiles() throws android.os.RemoteException;
/**
     * Returns the device currrent location profile (TYPE_TAG,TYPE_BASE etc...)
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
public int getLocationProfile() throws android.os.RemoteException;
/**
     * Returns a bitmap of location rate supported by the device (STATIC,AGILE,LOW,etc...)
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     * @return bitmap of device supported location rates
     */
public int getSupportedLocationRate() throws android.os.RemoteException;
/**
     * Returns the device currrent LocRate (STATIC,AGILE,LOW,etc..)
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
public int getLocationRate() throws android.os.RemoteException;
//********************************************************************************
//**********************  		Ranging control 	******************************
//********************************************************************************
/**
     * Set the Local adapter current profile.
     *
     * <p>This is an asynchronous call, it will return immediately.
     * Listen to {@link #onLocationProfilechanged()} to be notified when
     * the profile changed  and its result.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
	 * @param locationProfile : TYPE_TAG,TYPE_BASE etc..
     * @hide
     */
public int setLocationProfile(int locationProfile) throws android.os.RemoteException;
/**
     * Set device Location Rate.
     *
     * <p>This is an asynchronous call, it will return immediately.
     * Listen to {@link #onLocationRatechanged()} to be notified when
     * the location rate changed  and its result.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
	 * @param locationRate : LOCRATE_SLOW|MEDIUM|FAST|STATIC|AGILE
     * @hide
     */
public int setLocationRate(int locationRate) throws android.os.RemoteException;
//********************************************************************************
//**********************  		Sensor control 		******************************
//********************************************************************************
/**
     * Returns a bitmap of sensors supported by the device
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
 	 * @return bitmap of supported sensors (TYPE_ACCELEROMETER,TYPE_GRAVITY, etc..)
     */
public int getSupportedSensor() throws android.os.RemoteException;
/**
     * Get the device sensor max range and resolution
	 * @param : sensor Android sensor type :
	 *  TYPE_ACCELEROMETER,TYPE_GRAVITY,TYPE_GYROSCOPE,TYPE_MAGNETIC_FIELD,TYPE_PRESSURE...
	 * @param  maxRange : maximum range of the sensor in the sensor's unit.
	 * @param  resolution : resolution of the sensor in the sensor's unit.
	 * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
public void getSensorInfo(int sensor, float[] maxRange, float[] resolution) throws android.os.RemoteException;
/**
     * Get the device sensor last value
	 * @param sensor : Android sensor type
	 *  TYPE_ACCELEROMETER,TYPE_GRAVITY,TYPE_GYROSCOPE,TYPE_MAGNETIC_FIELD,TYPE_PRESSURE...
	 * @param  in sensor : the sensor we want to get data
	 * @param  out accuracy : the sensor last value accuracy
	 * @param  out timestamp : the sensor last value timestamp in nanosecond
	 * @param  out value : The length and contents of the value array depends on which sensor type is being monitored
	 * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
     */
public void getSensorValue(int sensor, int accuracy, long timestamp, float[] value) throws android.os.RemoteException;
//********************************************************************************
//*************************  		Data control 	******************************
//********************************************************************************
/**
     * Send data to the remote device.
     *
     * <p>This is an asynchronous call, it will return immediately.
     * Listen to {@link #onDeviceDatasent()} to be notified when
     * the data are sent, and its result.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION}
	 * @param data : byte stream
     * @hide
     */
public void sendData(byte[] data) throws android.os.RemoteException;
//********************************************************************************
//*************************  	Secure control 		******************************
//********************************************************************************
/**
     * Get secure key from device.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * @hide
     */
public void getSecureKey(byte[] key) throws android.os.RemoteException;
/**
     * set secure key of the device.
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * @hide
     */
public void setSecureKey(byte[] key) throws android.os.RemoteException;
//********************************************************************************
//*************************  	 MAC control 		******************************
//********************************************************************************
/**
     * Get device current IT_start mac settings
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * @hide
     */
public int getMacInfoItStart() throws android.os.RemoteException;
/**
     * Get device current IT_slot mac settings
     * <p>Requires {@link android.Manifest.permission#UWB_LOCATION_ADMIN}
     * @hide
     */
public int getMacInfoItSlot() throws android.os.RemoteException;
}
